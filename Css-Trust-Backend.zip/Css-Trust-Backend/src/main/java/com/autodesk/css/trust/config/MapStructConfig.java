package com.autodesk.css.trust.config;
//
//import org.springframework.context.annotation.Configuration;
//import org.mapstruct.MapperScan;
//
//@Configuration
//@MapperScan(basePackages = "com.autodesk.css.trust.entitities.mapper")
//public class MapStructConfig {
//    // Additional MapStruct configuration can be added here
//}