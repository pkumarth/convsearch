package com.autodesk.css.trust.api;

import com.autodesk.css.trust.common.res.ApiResponse;
import com.autodesk.css.trust.entitities.dto.AgentDto;
import com.autodesk.css.trust.entitities.dto.TaskDto;
import com.autodesk.css.trust.entitities.dto.TaskLogDto;
import com.autodesk.css.trust.entitities.models.TaskCreateRequest;
import com.autodesk.css.trust.entitities.models.TaskFilterRequest;
import com.autodesk.css.trust.services.AgentService;
import com.autodesk.css.trust.services.TaskCoreUseCase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/taskctrl")
//@PreAuthorize("hasRole('ADMIN')")
public class TaskPortalController {
    @Autowired
    AgentService agentService;

    @Autowired
    CommonRestUtils commonRestUtils;

    @Autowired
    TaskCoreUseCase taskCoreUseCase;

    @PostMapping("/create")
    public ResponseEntity<ApiResponse> createTask(@RequestBody TaskCreateRequest request, @RequestHeader HttpHeaders headers) throws Exception {
        AgentDto agentDto = agentService.findAgentById(request.getAgentId());
        boolean failed = false;

        if (agentDto == null) {
            failed = true;
        } else {
            try {
                taskCoreUseCase.createTask(agentDto.getId(), request);
                ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
                return new ResponseEntity<>(response, HttpStatus.OK);
            }catch (Exception e) {
                failed = true;
            }
        }
        ApiResponse response = commonRestUtils.getResponseTemplate(false, 500, "Invalid Credentials", "Invalid Credentials");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @PostMapping("/getAll")
    public ResponseEntity<ApiResponse> getAllTasks(
            @RequestBody TaskFilterRequest filter
    ) {
        if(filter == null) {
            filter = new TaskFilterRequest();
        }
        if(filter.getPage() == null) {
            filter.setPage(0);
        }

        if(filter.getSize() == null) {
            filter.setSize(-1);
        }
        List<TaskDto> tasks = taskCoreUseCase.getAllTasks(filter, filter.getPage(), filter.getSize(), filter.getSortBy());
        ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
        response.setResult(CommonRestUtils.listToMap(Collections.singletonList(tasks),"content"));
        return ResponseEntity.ok(response);
    }
    @GetMapping("/getById")
    public ResponseEntity<ApiResponse> getById(@RequestParam(name = "id") Long taskId) {
        TaskFilterRequest filter = new TaskFilterRequest();
        filter.setPage(0);
        filter.setSize(100);
        filter.setTaskId(taskId);

        TaskDto taskDto = taskCoreUseCase.getAllTasks(filter, 0,100,"taskId").get(0);
        ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");

        List<TaskLogDto> taskLogDtoList = taskCoreUseCase.getAllTasksLogs(taskId);
        Map<String,Object> map = new HashMap<>();
        map.put("logs",taskLogDtoList);
        map.put("task",taskDto);

        response.setResult( map);
        return ResponseEntity.ok(response);
    }


    @PostMapping("/getAllTaskLogs")
    public ResponseEntity<ApiResponse> getAllTasksLog(
            @RequestBody TaskFilterRequest filter
    ) {
        if(filter == null) {
            filter = new TaskFilterRequest();
        }
        if(filter.getPage() == null) {
            filter.setPage(0);
        }

        if(filter.getSize() == null) {
            filter.setSize(-1);
        }
        List<TaskLogDto> tasks = taskCoreUseCase.getAllTasksLogs(filter.getTaskId());// .getAllTasks(filter, filter.getPage(), filter.getSize(), filter.getSortBy());
        ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
        response.setResult(CommonRestUtils.listToMap(Collections.singletonList(tasks),"content"));
        return ResponseEntity.ok(response);
    }
}
