package com.autodesk.css.trust.api;


import com.autodesk.css.trust.common.res.ApiResponse;
import com.autodesk.css.trust.entitities.dto.DashQueryMapDto;
import com.autodesk.css.trust.entitities.dto.WidgetData;
import com.autodesk.css.trust.services.AnalyticsService;
import com.autodesk.css.trust.services.DashQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController

@RequestMapping("/analytics")
public class AnalyticsDataController {
    @Autowired
    private AnalyticsService analyticsService;

    @Autowired
    private DashQueryService dashQueryService;

    @GetMapping("/latest")
    public ResponseEntity<ApiResponse> getLatestSnapshot(
            @RequestParam(name = "d", required = false) String d,
            @RequestParam(name = "w", required = false) String w) {

        validateString(d);
        validateString(w);

        DashQueryMapDto queryMapDto = dashQueryService.findByObjectIdAndDashboardName(w.trim(), d.trim());
        if (queryMapDto != null) {
            String sql = queryMapDto.getSqlQuery();
            if (!ObjectUtils.isEmpty(sql)) {
                List<Map<String, Object>> a = analyticsService.fetchAnalyticsData(sql, null);
                if (!ObjectUtils.isEmpty(a)) {
                    System.out.println(a);
                    ApiResponse response = CommonRestUtils.getSuccessResponseTemplate();
                    response.setResult(a.get(0));
                    return ResponseEntity.ok(response);
                }
            }
        }
        return ResponseEntity.ok(CommonRestUtils.getSuccessResponseTemplate());
    }

    @GetMapping("/all")
    public ResponseEntity<ApiResponse> getAllSnapshot(
            @RequestParam(name = "d", required = false) String d,
            @RequestParam(name = "fromTimestamp", required = false) String fromTimestamp,
            @RequestParam(name = "toTimestamp", required = false) String toTimestamp,
            @RequestParam(name = "env", required = false) String env,
            @RequestParam(name = "account_id", required = false) String account_id) {
        validateString(d);
        //todo create map and put data
        Map<String, String> params = new HashMap<>();
        params.put("$account_id", "");

        if (!ObjectUtils.isEmpty(fromTimestamp)) {
            params.put("$fromTimestamp", "TO_TIMESTAMP(" + fromTimestamp + ")");
        }
        if (!ObjectUtils.isEmpty(toTimestamp)) {
            params.put("$toTimestamp", "TO_TIMESTAMP(" + toTimestamp + ")");
        }
        if (!ObjectUtils.isEmpty(env)) {
            params.put("$env", env);
        }
        if (!ObjectUtils.isEmpty(account_id)) {
            params.put("$account_id", account_id);
        }

        Map<String, String> map = dashQueryService.getAllValues(d.trim());
        List<WidgetData> list = new ArrayList<>();
        Map<String, Object> res = new HashMap<>();

//        DashQueryMapDto  queryMapDto = dashQueryService.getAllValues(d.trim());
        if (!ObjectUtils.isEmpty(map)) {
            for (Map.Entry<String, String> entry : map.entrySet()) {
//                System.out.println(entry.getKey() + ": " + entry.getValue());
                try {
                    List<Map<String, Object>> a = analyticsService.fetchAnalyticsData(entry.getValue(), params);
                    WidgetData widgetData = new WidgetData();
                    widgetData.setWidgetId(entry.getKey());
                    widgetData.setWidgetData(a);

                    list.add(widgetData);
                } catch (Exception e) {
                    System.out.println("Err:" + entry.getKey() + ": " + entry.getValue());
                }
            }
            res.put("dashboardData", list);
            ApiResponse response = CommonRestUtils.getSuccessResponseTemplate();
            response.setResult(res);
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.ok(CommonRestUtils.getSuccessResponseTemplate());
    }

    public void validateString(String input) throws IllegalArgumentException {
        // Check if string length is above 20
        if (ObjectUtils.isEmpty(input) || input.length() > 20 || !input.matches("^[a-zA-Z0-9]*$")) {
            throw new IllegalArgumentException("Invalid input");
        }
    }
}
