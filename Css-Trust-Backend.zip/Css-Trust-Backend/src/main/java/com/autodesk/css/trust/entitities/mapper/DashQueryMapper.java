package com.autodesk.css.trust.entitities.mapper;


import com.autodesk.css.trust.entitities.dto.DashQueryMapDto;
import com.autodesk.css.trust.entitities.entity.DashQueryMapEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface DashQueryMapper {
    DashQueryMapDto toDto(DashQueryMapEntity dashQueryMapEntity);
    DashQueryMapEntity toEntity(DashQueryMapDto dashQueryMapDto);
}