package com.autodesk.css.trust.api;

import com.autodesk.css.trust.common.res.ApiResponse;
import com.autodesk.css.trust.entitities.dto.AgentDto;
import com.autodesk.css.trust.services.AgentService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class CommonRestUtils {
    @Autowired
    AgentService agentService;



    public AgentDto getAgent(HttpHeaders headers){

        String clientId = headers.getFirst("client-id");
        String clientSecret = headers.getFirst("client-secret");
        if(clientId != null && clientSecret != null){
            AgentDto agentDto = agentService.verifyAgent(clientId, clientSecret);
            return agentDto;
        }
        return null;
    }
    public ApiResponse getResponseTemplate(boolean success, Integer code, String message, String cause){
        ApiResponse response = new ApiResponse();
        response.setSuccess(success);
        response.setMessage(message);
        response.setCode(code);
        response.setCause(cause);
        return response;
    }
    public static ApiResponse getSuccessResponseTemplate(){
        ApiResponse response = new ApiResponse();
        response.setSuccess(true);
        response.setCause("Successfully Done!");
        response.setMessage("Successfully Done!");
        response.setCode(200);
        return response;
    }
    public static synchronized Map<String,Object> pojoToMap(Object pojo){
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> map = objectMapper
                .convertValue(pojo, new TypeReference<Map<String, Object>>() {});
        return map;
    }
    public static synchronized Map<String,Object> listToMap(List<Object> pojo,String key){
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> objectMap = new HashMap<>();
        objectMap.put(key, pojo);
        Map<String, Object> map = objectMapper
                .convertValue(objectMap, new TypeReference<Map<String, Object>>() {});
        return map;
    }
}
