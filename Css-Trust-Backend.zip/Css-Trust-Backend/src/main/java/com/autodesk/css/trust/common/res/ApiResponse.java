package com.autodesk.css.trust.common.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Map;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class ApiResponse {
    private boolean success;
    private Integer code;
    private String message;
    private String cause;
    private Map<String, Object> result;
}


