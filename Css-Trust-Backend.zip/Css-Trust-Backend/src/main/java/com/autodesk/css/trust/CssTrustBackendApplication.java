package com.autodesk.css.trust;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CssTrustBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CssTrustBackendApplication.class, args);
	}

}
