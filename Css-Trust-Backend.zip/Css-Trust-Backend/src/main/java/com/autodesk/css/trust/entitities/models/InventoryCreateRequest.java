package com.autodesk.css.trust.entitities.models;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class InventoryCreateRequest {
    @NotBlank(message = "Cloud Name is required")
    @Size(min = 2, max = 255, message = "Cloud Name must be between 2 and 255 characters")
    private String location;
    @NotBlank(message = "Environment is required")
    @Size(min = 2, max = 255, message = "Environment must be between 2 and 255 characters")
    private String environment;
    private String accountId;
    private String accountName;
    private String instanceId;
    @NotBlank(message = "Ip is required")
    @Size(min = 7, max = 15, message = "Host Name must be between 7 and 15 characters")
    private String ip;
    @NotBlank(message = "Os Type is required")
    @Size(min = 2, max = 255, message = "Os Type must be between 2 and 255 characters")
    private String osType;

    @NotBlank(message = "Host Name is required")
    @Size(min = 2, max = 255, message = "Host Name must be between 2 and 255 characters")
    private String hostName;



    private String group;
    @NotBlank(message = "Ssh User is required")
    @Size(min = 2, max = 255, message = "Ssh User must be between 2 and 255 characters")
    private String sshUser;
    private String hostStatus;
    private String lastChecked;
    private String serverLocation;
    private String applicationName;
    private String edrStatus;
    private String patchingStatus;
    private Boolean pathAvailable;


}
