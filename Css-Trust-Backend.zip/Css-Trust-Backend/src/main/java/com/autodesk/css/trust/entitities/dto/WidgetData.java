package com.autodesk.css.trust.entitities.dto;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class WidgetData {
    private String widgetId;
    private List<Map<String, Object>> widgetData;
}
