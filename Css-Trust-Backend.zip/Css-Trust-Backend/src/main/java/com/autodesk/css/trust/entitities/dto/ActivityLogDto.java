package com.autodesk.css.trust.entitities.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActivityLogDto {

    private Long id;
    private Long actorId;
    private String actorType;
    private LocalDateTime dateTime;
    private String action;
    private String actionDetails;
}
