package com.autodesk.css.trust.entitities.mapper;



import com.autodesk.css.trust.entitities.dto.TaskDto;
import com.autodesk.css.trust.entitities.entity.TaskEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.data.domain.Page;

import java.util.List;

@Mapper(componentModel = "spring")
public interface TaskMapper {

    TaskMapper INSTANCE = Mappers.getMapper(TaskMapper.class);

    TaskEntity toTaskEntity(TaskDto taskDto);

    TaskDto toTaskDto(TaskEntity taskEntity);

    List<TaskDto> toDtoList(List<TaskEntity> entities);

    List<TaskDto> toDtoPage(Page<TaskEntity> entityPage);
}