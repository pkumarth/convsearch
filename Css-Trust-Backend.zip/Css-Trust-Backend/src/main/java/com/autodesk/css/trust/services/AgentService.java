package com.autodesk.css.trust.services;

import com.autodesk.css.trust.entitities.dto.AgentDto;
import com.autodesk.css.trust.entitities.entity.AgentEntity;
import com.autodesk.css.trust.entitities.mapper.AgentMapper;
import com.autodesk.css.trust.repo.AgentRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@AllArgsConstructor
//@Transactional
public class AgentService {

    private AgentRepository agentRepository;

//    @Autowired
//    PasswordEncoder passwordEncoder;


    private AgentMapper agentMapper;

    public AgentDto verifyAgent(String agentId, String agentSecret) {
        AgentEntity agentEntity = agentRepository.findByAgentClientId(agentId);
//        AgentMapper ab = AgentMapper.INSTANCE;

//        if(agentEntity!=null && passwordEncoder.matches(agentSecret, agentEntity.getAgentSecret())) {
//            return agentMapper.toAgentDto( agentEntity);
//        }

        return null;
    }

    public AgentDto findAgent(String agentId) {
        AgentEntity agentEntity = agentRepository.findByAgentClientId(agentId);
        return agentMapper.toAgentDto(agentEntity);
    }

    public boolean updateAgentLastLogTime(AgentDto agent, LocalDateTime lastLogTime) {

        if (agent == null)
            return false;

        agentRepository.updateAgentLastLogTime(agent.getAgentClientId(), lastLogTime);
        return true;
    }


    public AgentDto findAgentById(Long agentId) throws Exception {
        if (agentId == null) {
            throw new Exception("Agent Id is required");
        }
        AgentEntity agentEntity = agentRepository.findById(agentId).get();
        AgentDto agentDto = agentMapper.toAgentDto(agentEntity);
        return agentDto;
    }
}
