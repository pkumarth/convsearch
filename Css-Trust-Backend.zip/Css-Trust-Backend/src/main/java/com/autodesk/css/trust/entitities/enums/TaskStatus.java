package com.autodesk.css.trust.entitities.enums;

public enum TaskStatus {
    QUEUED,IN_PROGRESS,COMPLETED,FAILED
}
