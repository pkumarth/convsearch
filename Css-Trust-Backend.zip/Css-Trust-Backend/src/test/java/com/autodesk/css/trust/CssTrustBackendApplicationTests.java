package com.autodesk.css.trust;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
//class CssTrustBackendApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
