package com.samsung.convsearch.convsearch_api.dao;


import com.samsung.convsearch.convsearch_api.entity.InsuranceFormModel;

import java.util.List;

public interface InsuranceFormDao {
    InsuranceFormModel update(InsuranceFormModel dtoSource);

    InsuranceFormModel save(InsuranceFormModel dtoSource);

    InsuranceFormModel findById(String id);

    List<InsuranceFormModel> findByGsi(String partitionKey, String sortKey, String gsiName);
}
