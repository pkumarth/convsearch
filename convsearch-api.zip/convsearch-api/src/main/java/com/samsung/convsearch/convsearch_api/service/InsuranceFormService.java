package com.samsung.convsearch.convsearch_api.service;


import com.samsung.convsearch.convsearch_api.dto.BaseResponseDTO;
import com.samsung.convsearch.convsearch_api.entity.InsuranceFormModel;

import java.util.Map;

public interface InsuranceFormService {
    BaseResponseDTO update(InsuranceFormModel dtoSource);

    BaseResponseDTO save(InsuranceFormModel dtoSource);

    BaseResponseDTO findById(String id);

    public BaseResponseDTO search(Map<String, String> params);
}
