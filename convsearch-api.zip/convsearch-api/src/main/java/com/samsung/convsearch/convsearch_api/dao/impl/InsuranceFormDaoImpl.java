package com.samsung.convsearch.convsearch_api.dao.impl;



import com.samsung.convsearch.convsearch_api.dao.InsuranceFormDao;
import com.samsung.convsearch.convsearch_api.entity.InsuranceFormModel;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Repository
public class InsuranceFormDaoImpl implements InsuranceFormDao {
    @Autowired
    private DynamoDbEnhancedClient dynamoDbenhancedClient;

    @Autowired
    private ModelMapper modelMapper;

    private DynamoDbTable<InsuranceFormModel> getTable() {
        return dynamoDbenhancedClient.table(InsuranceFormModel.TABLE, TableSchema.fromBean(InsuranceFormModel.class));
    }


    public InsuranceFormModel update(InsuranceFormModel dtoSource) {
        // if id is null which means only save api is called
        if (ObjectUtils.isEmpty(dtoSource.getId())) {
            save(dtoSource);
        }
        // check if record exist in db
        InsuranceFormModel dbDestination = findById(dtoSource.getId());
        //  if record does not exist
        if (dbDestination == null) {
            dtoSource.create();
            return getTable().updateItem(dtoSource);
        }
        //  if record exist
        dtoSource.update(dbDestination.getVersion());
        modelMapper.map(dtoSource, dbDestination);
        return getTable().updateItem(dbDestination);
    }

    public InsuranceFormModel save(InsuranceFormModel InsuranceFormModel) {
        InsuranceFormModel.create();
        InsuranceFormModel.setId(UUID.randomUUID().toString());
        return update(InsuranceFormModel);
    }

    public InsuranceFormModel findById(String id) {
        Key key = Key.builder().partitionValue(id).build();
        return getTable().getItem(key);
    }

    public List<InsuranceFormModel> findByGsi(String partitionKey, String sortKey, String gsiName) {
        List<InsuranceFormModel> models = new ArrayList<>();
        //QueryConditional q = QueryConditional.keyEqualTo(Key.builder().partitionValue(partitionKey.trim()).build());
        QueryConditional q = ObjectUtils.isEmpty(sortKey)
                ? QueryConditional.keyEqualTo(Key.builder().partitionValue(partitionKey.trim()).build())
                : QueryConditional.keyEqualTo(Key.builder().partitionValue(partitionKey.trim()).sortValue(sortKey).build());
        getTable().index(gsiName).query(q).forEach(result -> {
            models.addAll(result.items());
        });
        return models;
    }
}

