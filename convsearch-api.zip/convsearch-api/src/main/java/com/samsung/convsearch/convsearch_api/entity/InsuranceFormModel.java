package com.samsung.convsearch.convsearch_api.entity;


import com.samsung.convsearch.convsearch_api.entity.enums.InsuranceProductType;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.*;

@Setter
@AllArgsConstructor
@NoArgsConstructor
@DynamoDbBean
public class InsuranceFormModel extends AuditModel {
    public static final String TABLE = "mga_insurance_forms";
    public static final String STATECODE_GSI = "state_code_gsi";
    public static final String CARRIERCODE_GSI = "carrier_code_gsi";
    public static final String STATECODE = "stateCode";
    public static final String CARRIERCODE = "carrierCode";
    public static final String FORMNAME = "formName";


    private String id;
    private String carrierCode;
    private String stateCode;
    private String formName;
    private InsuranceProductType insuranceProductType;

    private String inputBucket;
    private String inputKeyPath;
    private String inputKeyName;

    private String outputBucket;
    private String outputKeyPath;
    private String outputKeyName;

    private String displayName;


    private String description;
    private Long order;
    private Boolean mandatory;

    @DynamoDbPartitionKey
    @DynamoDbAttribute("id")
    public String getId() {
        return id;
    }

    @DynamoDbSecondaryPartitionKey(indexNames = {CARRIERCODE_GSI})
    @DynamoDbAttribute("carrier_code")
    public String getCarrierCode() {
        return carrierCode;
    }


    //@DynamoDbSecondarySortKey(indexNames = {CARRIERCODE})
    //@DynamoDbSecondaryPartitionKey(indexNames = {STATECODE})
    @DynamoDbSecondarySortKey(indexNames = {CARRIERCODE_GSI})
    @DynamoDbAttribute("state_code")
    public String getStateCode() {
        return stateCode;
    }

    //@DynamoDbSecondarySortKey(indexNames = {STATECODE,CARRIERCODE})
    @DynamoDbAttribute("form_name")
    public String getFormName() {
        return formName;
    }

    @DynamoDbAttribute("input_s3_bucket")
    public String getInputBucket() {
        return inputBucket;
    }

    @DynamoDbAttribute("input_s3_key_path")
    public String getInputKeyPath() {
        return inputKeyPath;
    }

    @DynamoDbAttribute("input_s3_key_name")
    public String getInputKeyName() {
        return inputKeyName;
    }

    @DynamoDbAttribute("output_s3_bucket")
    public String getOutputBucket() {
        return outputBucket;
    }

    @DynamoDbAttribute("output_s3_key_path")
    public String getOutputKeyPath() {
        return outputKeyPath;
    }

    @DynamoDbAttribute("output_s3_key_name")
    public String getOutputKeyName() {
        return outputKeyName;
    }

    @DynamoDbAttribute("display_name")
    public String getDisplayName() {
        return displayName;
    }


    @DynamoDbAttribute("insurance_type")
    public InsuranceProductType getInsuranceProductType() {
        return insuranceProductType;
    }

    @DynamoDbAttribute("description")
    public String getDescription() {
        return description;
    }

    @DynamoDbAttribute("order")
    public Long getOrder() {
        return order;
    }

    @DynamoDbAttribute("is_mandatory")
    public Boolean getMandatory() {
        return mandatory;
    }
}

