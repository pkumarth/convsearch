package com.samsung.convsearch.convsearch_api.api;


import com.samsung.convsearch.convsearch_api.dto.BaseResponseDTO;
import com.samsung.convsearch.convsearch_api.entity.InsuranceFormModel;
import com.samsung.convsearch.convsearch_api.service.InsuranceFormService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
@RestController
@RequestMapping(value = "/public/api/v1")
@RequiredArgsConstructor
public class InsuranceFormApi {
    @Autowired
    private InsuranceFormService insuranceFormService;

    @GetMapping("/insur-form/{id}")
    public ResponseEntity<BaseResponseDTO> findById(@PathVariable(required = false) String id) {
        return ResponseEntity.ok(insuranceFormService.findById(id));
    }

    @GetMapping("/insur-form/search")
    public ResponseEntity<BaseResponseDTO> search(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(insuranceFormService.search(params));
    }

    @PostMapping("/insur-form")
    public ResponseEntity<BaseResponseDTO> upsert(@RequestBody InsuranceFormModel dtoSource) {
        return ResponseEntity.ok(insuranceFormService.save(dtoSource));
    }
}
