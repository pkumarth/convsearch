package com.samsung.convsearch.convsearch_api.entity.enums;

public enum InsuranceProductType {
    CYBER
}
