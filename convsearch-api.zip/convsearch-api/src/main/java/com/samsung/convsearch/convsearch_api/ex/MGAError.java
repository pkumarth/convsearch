package com.samsung.convsearch.convsearch_api.ex;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class MGAError {
    private String messages;

    public MGAError(String messages) {
        this.messages = messages;
    }
}