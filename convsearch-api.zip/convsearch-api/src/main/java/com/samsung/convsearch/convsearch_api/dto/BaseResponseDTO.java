package com.samsung.convsearch.convsearch_api.dto;



import com.samsung.convsearch.convsearch_api.ex.MGAError;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Getter
@Data
public class BaseResponseDTO<T> {

    private Boolean success = Boolean.TRUE;

    private String message;

    private T data;

    private List<MGAError> errors;

    public BaseResponseDTO(Boolean success, String message, T data, List<MGAError> errors) {
        this.success = success;
        this.message = message;
        this.data = data;
        this.errors = errors;
    }

    public BaseResponseDTO(String message, T data) {
        this.message = message;
        this.data = data;
    }

    public BaseResponseDTO(Boolean success, String message, List<MGAError> errors) {
        this.success = success;
        this.message = message;
        this.errors = errors;
    }
}

