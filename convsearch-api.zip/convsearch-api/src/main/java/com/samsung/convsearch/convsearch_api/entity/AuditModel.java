package com.samsung.convsearch.convsearch_api.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Objects;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuditModel {
    private Long version;
    private Boolean is_deleted;
    private String created_by;
    private String updated_by;
    private LocalDate created_dt;
    private LocalDate updated_dt;


    public void update(Long version) {
        this.updated_dt = LocalDate.now();
        this.version = version == null ? 0 : version + 1;
        this.updated_by = Objects.isNull(updated_by) ? "System" : updated_by;
    }


    public void create() {
        update(null);
        this.is_deleted = false;
        this.created_dt = LocalDate.now();
        this.created_by = Objects.isNull(created_by) ? "System" : created_by;

    }
}
