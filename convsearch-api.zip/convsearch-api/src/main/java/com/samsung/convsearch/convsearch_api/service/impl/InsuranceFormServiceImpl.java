package com.samsung.convsearch.convsearch_api.service.impl;



import com.samsung.convsearch.convsearch_api.dao.InsuranceFormDao;
import com.samsung.convsearch.convsearch_api.dto.BaseResponseDTO;
import com.samsung.convsearch.convsearch_api.entity.InsuranceFormModel;
import com.samsung.convsearch.convsearch_api.service.InsuranceFormService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class InsuranceFormServiceImpl implements InsuranceFormService {
    @Autowired
    private InsuranceFormDao insuranceFormDao;

    @Override
    public BaseResponseDTO update(InsuranceFormModel dtoSource) {
        return new BaseResponseDTO(true, "Document Updated successfully", insuranceFormDao.update(dtoSource), null);


    }

    @Override
    public BaseResponseDTO save(InsuranceFormModel dtoSource) {
        return new BaseResponseDTO(true, "Document created successfully", insuranceFormDao.update(dtoSource), null);
    }

    @Override
    public BaseResponseDTO findById(String id) {
        return new BaseResponseDTO(true, "Document retrieved successfully", insuranceFormDao.findById(id), null);


    }

    public BaseResponseDTO search(Map<String, String> params) {
        String carrierCode = params.get(InsuranceFormModel.CARRIERCODE);
        String stateCode = params.get(InsuranceFormModel.STATECODE);
        String formName = params.get(InsuranceFormModel.FORMNAME).trim();
        log.info("Retrieving: {} for {} & {}", formName, carrierCode, stateCode);
        List<InsuranceFormModel> models = null;
        if (!ObjectUtils.isEmpty(carrierCode)) {
            models = insuranceFormDao.findByGsi(carrierCode, stateCode, InsuranceFormModel.CARRIERCODE_GSI);
        } else if (!ObjectUtils.isEmpty(stateCode)) {
            models = insuranceFormDao.findByGsi(stateCode, null, InsuranceFormModel.STATECODE_GSI);
        } else {
            log.warn("Neither carrierCode nor stateCode provided for {}", formName);
            return null;
        }
        List<InsuranceFormModel> resModels = null;
        if(!ObjectUtils.isEmpty(formName)) {
            resModels = models.stream()
                    .filter(model -> formName.equalsIgnoreCase(model.getFormName()))
                    .collect(Collectors.toList());
        } else{
            resModels = models;
        }
        log.info("Found {} for {} for {} & {}", resModels.size(), formName, carrierCode, stateCode);
        return new BaseResponseDTO(true, "Document retrieved successfully", resModels, null);
    }

}