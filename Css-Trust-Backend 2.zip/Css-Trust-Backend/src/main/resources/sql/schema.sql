SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

CREATE TABLE public.activity_log (
                                     id bigint NOT NULL,
                                     actor_id bigint,
                                     actor_type character varying(255),
                                     date_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
                                     action character varying(255),
                                     action_details character varying(255)
);

CREATE SEQUENCE public.activity_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.activity_log_id_seq OWNED BY public.activity_log.id;



--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.activity_log (
                                     id bigint NOT NULL,
                                     actor_id bigint,
                                     actor_type character varying(255),
                                     date_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
                                     action character varying(255),
                                     action_details character varying(255)
);


--
-- Name: activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: vrathi
--

CREATE SEQUENCE public.activity_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vrathi
--

ALTER SEQUENCE public.activity_log_id_seq OWNED BY public.activity_log.id;


--
-- Name: agent_master; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.agent_master (
                                     id bigint NOT NULL,
                                     agent_name character varying(255) NOT NULL,
                                     agent_client_id character varying(255) NOT NULL,
                                     agent_secret character varying(255) NOT NULL,
                                     agent_status character varying(255) DEFAULT 'ACTIVE'::character varying,
                                     agent_lastreportedtime timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
                                     agent_last_reported_time timestamp(6) without time zone NOT NULL
);



--
-- Name: agent_master_id_seq; Type: SEQUENCE; Schema: public; Owner: vrathi
--

CREATE SEQUENCE public.agent_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vrathi
--

ALTER SEQUENCE public.agent_master_id_seq OWNED BY public.agent_master.id;


--
-- Name: host_metrics_snapshot; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.host_metrics_snapshot (
                                              id bigint NOT NULL,
                                              "timestamp" timestamp without time zone NOT NULL,
                                              total_hosts integer NOT NULL,
                                              total_linux_hosts integer NOT NULL,
                                              total_mac_hosts integer NOT NULL,
                                              total_windows_hosts integer NOT NULL,
                                              linux_host_without_edr integer NOT NULL,
                                              linux_host_with_edr integer NOT NULL,
                                              mac_host_without_edr integer NOT NULL,
                                              mac_host_with_edr integer NOT NULL,
                                              windows_host_without_edr integer NOT NULL,
                                              windows_host_with_edr integer NOT NULL,
                                              hosts_with_edr integer NOT NULL,
                                              hosts_without_edr integer NOT NULL,
                                              linux_host_unhealthy_edr integer NOT NULL,
                                              mac_host_unhealthy_edr integer NOT NULL,
                                              windows_host_unhealthy_edr integer NOT NULL,
                                              hosts_with_unhealthy_edr integer NOT NULL,
                                              attempted_host_patching integer NOT NULL,
                                              successful_host_patching integer NOT NULL,
                                              failed_host_patching integer NOT NULL,
                                              raw text
);


--
-- Name: host_metrics_snapshot_id_seq; Type: SEQUENCE; Schema: public; Owner: vrathi
--

CREATE SEQUENCE public.host_metrics_snapshot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;



--
-- Name: host_metrics_snapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vrathi
--

ALTER SEQUENCE public.host_metrics_snapshot_id_seq OWNED BY public.host_metrics_snapshot.id;



--
-- Name: task_logs; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.task_logs (
                                  task_log_id bigint NOT NULL,
                                  task_id bigint,
                                  log_datetime timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
                                  log_message text,
                                  progress_percentage integer,
                                  log_date_time timestamp(6) without time zone NOT NULL,
                                  CONSTRAINT task_logs_progress_percentage_check CHECK (((progress_percentage >= 0) AND (progress_percentage <= 100)))
);


--
-- Name: task_logs_task_log_id_seq; Type: SEQUENCE; Schema: public; Owner: vrathi
--

CREATE SEQUENCE public.task_logs_task_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_logs_task_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vrathi
--

ALTER SEQUENCE public.task_logs_task_log_id_seq OWNED BY public.task_logs.task_log_id;



--
-- Name: task_master; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.task_master (
                                    task_id bigint NOT NULL,
                                    task_name character varying(255) NOT NULL,
                                    task_type character varying(255),
                                    task_subtype character varying(255),
                                    task_tags text,
                                    task_input text,
                                    task_agent_id bigint,
                                    task_status character varying(255) DEFAULT 'PENDING'::character varying,
                                    task_logs text,
                                    progress integer DEFAULT 0,
                                    task_sub_type character varying(255),
                                    task_result text,
                                    task_start_time timestamp without time zone,
                                    task_end_time timestamp without time zone,
                                    CONSTRAINT task_master_progress_check CHECK (((progress >= 0) AND (progress <= 100)))
);


--
-- Name: task_master_task_id_seq; Type: SEQUENCE; Schema: public; Owner: vrathi
--

CREATE SEQUENCE public.task_master_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

--
-- Name: task_master_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vrathi
--

ALTER SEQUENCE public.task_master_task_id_seq OWNED BY public.task_master.task_id;



--
-- Name: activity_log id; Type: DEFAULT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.activity_log ALTER COLUMN id SET DEFAULT nextval('public.activity_log_id_seq'::regclass);


--
-- Name: agent_master id; Type: DEFAULT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.agent_master ALTER COLUMN id SET DEFAULT nextval('public.agent_master_id_seq'::regclass);


--
-- Name: host_metrics_snapshot id; Type: DEFAULT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.host_metrics_snapshot ALTER COLUMN id SET DEFAULT nextval('public.host_metrics_snapshot_id_seq'::regclass);


--
-- Name: task_logs task_log_id; Type: DEFAULT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_logs ALTER COLUMN task_log_id SET DEFAULT nextval('public.task_logs_task_log_id_seq'::regclass);


--
-- Name: task_master task_id; Type: DEFAULT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_master ALTER COLUMN task_id SET DEFAULT nextval('public.task_master_task_id_seq'::regclass);



--
-- Name: activity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vrathi
--

SELECT pg_catalog.setval('public.activity_log_id_seq', 1, false);


--
-- Name: agent_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vrathi
--

SELECT pg_catalog.setval('public.agent_master_id_seq', 2, true);


--
-- Name: host_metrics_snapshot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vrathi
--

SELECT pg_catalog.setval('public.host_metrics_snapshot_id_seq', 732, true);


--
-- Name: task_logs_task_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vrathi
--

SELECT pg_catalog.setval('public.task_logs_task_log_id_seq', 20, true);


--
-- Name: task_master_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vrathi
--

SELECT pg_catalog.setval('public.task_master_task_id_seq', 17, true);



--
-- Name: activity_log activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_pkey PRIMARY KEY (id);


--
-- Name: agent_master agent_master_agent_client_id_key; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.agent_master
    ADD CONSTRAINT agent_master_agent_client_id_key UNIQUE (agent_client_id);


--
-- Name: agent_master agent_master_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.agent_master
    ADD CONSTRAINT agent_master_pkey PRIMARY KEY (id);


--
-- Name: host_metrics_snapshot host_metrics_snapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.host_metrics_snapshot
    ADD CONSTRAINT host_metrics_snapshot_pkey PRIMARY KEY (id);

--
-- Name: task_logs task_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_logs
    ADD CONSTRAINT task_logs_pkey PRIMARY KEY (task_log_id);


--
-- Name: task_master task_master_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_master
    ADD CONSTRAINT task_master_pkey PRIMARY KEY (task_id);



--
-- Name: idx_failed_patching; Type: INDEX; Schema: public; Owner: vrathi
--

CREATE INDEX idx_failed_patching ON public.host_metrics_snapshot USING btree (failed_host_patching);


--
-- Name: idx_timestamp; Type: INDEX; Schema: public; Owner: vrathi
--

CREATE INDEX idx_timestamp ON public.host_metrics_snapshot USING btree ("timestamp");


--
-- Name: idx_unhealthy_edr; Type: INDEX; Schema: public; Owner: vrathi
--

CREATE INDEX idx_unhealthy_edr ON public.host_metrics_snapshot USING btree (hosts_with_unhealthy_edr);


--
-- Name: task_logs task_logs_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_logs
    ADD CONSTRAINT task_logs_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.task_master(task_id);


--
-- Name: task_master task_master_task_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_master
    ADD CONSTRAINT task_master_task_agent_id_fkey FOREIGN KEY (task_agent_id) REFERENCES public.agent_master(id);































