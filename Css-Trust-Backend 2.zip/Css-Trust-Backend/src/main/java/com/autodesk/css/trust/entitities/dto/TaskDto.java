package com.autodesk.css.trust.entitities.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskDto {

    private Long taskId;
    private String taskName;
    private String taskType;
    private String taskSubType;

    private String taskTags;
    private String taskInput;
    // Consider including agent information in a more concise way, e.g.,
    // private String agentName;
    // or
    // private Long agentId;
    private String taskStatus;
    private String taskLogs;
    private Integer progress;
    private Date taskStartTime;
    private Date taskEndTime;
}
