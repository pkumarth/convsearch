package com.autodesk.css.trust.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Base64;

@Component
@AllArgsConstructor
public class TaskHelper {
    public static String extractAndEncode(String inputJson) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        // Step 1: Parse the original JSON
        JsonNode root = mapper.readTree(inputJson);
        // Step 2: Convert JsonNode to compact JSON string
        String compactJson = mapper.writeValueAsString(root);
        // Step 3: Base64 encode it
        return Base64.getEncoder().encodeToString(compactJson.getBytes());
    }
}
