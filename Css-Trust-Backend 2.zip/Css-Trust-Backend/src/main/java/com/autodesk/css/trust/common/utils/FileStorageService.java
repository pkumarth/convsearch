//package com.autodesk.css.trust.common.utils;
//
//import jakarta.annotation.PostConstruct;
//import org.apache.coyote.BadRequestException;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//import org.springframework.util.StringUtils;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.nio.file.StandardCopyOption;
//import java.util.UUID;
//
//@Service
//public class FileStorageService {
//    @Value("${app.file.upload-dir}")
//    private String uploadDir;
//
//    @PostConstruct
//    public void init() {
//        try {
//            Files.createDirectories(Paths.get(uploadDir));
//        } catch (IOException ex) {
//            throw new RuntimeException("Could not create upload directory");
//        }
//    }
//
//    public String storeFile(MultipartFile file) {
//        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
//        String fileExtension = StringUtils.getFilenameExtension(fileName);
//        String storedFileName = UUID.randomUUID().toString() + "." + fileExtension;
//
//        try {
//            if (fileName.contains("..")) {
//                throw new BadRequestException("Invalid file path");
//            }
//
//            Path targetLocation = Paths.get(uploadDir).resolve(storedFileName);
//            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
//
//            return storedFileName;
//        } catch (IOException ex) {
//            throw new RuntimeException("Could not store file " + fileName);
//        }
//    }
//}