package com.autodesk.css.trust.entitities.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AgentDto {

    private Long id;
    private String agentName;
    private String agentClientId;
    private String agentStatus;
    private LocalDateTime agentLastReportedTime;
}
