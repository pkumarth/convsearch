package com.autodesk.css.trust.entitities.mapper;


import com.autodesk.css.trust.entitities.dto.HostMetricsSnapshotDto;
import com.autodesk.css.trust.entitities.entity.HostMetricsSnapshotEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.data.domain.Page;

import java.util.List;


@Mapper(componentModel = "spring")
public interface HostMetricsMapper {

    HostMetricsMapper INSTANCE = Mappers.getMapper(HostMetricsMapper.class);

    HostMetricsSnapshotEntity toEntity(HostMetricsSnapshotDto hostMetricsSnapshotDtoDto);

    HostMetricsSnapshotDto toDto(HostMetricsSnapshotEntity taskEntity);

    List<HostMetricsSnapshotDto> toDtoList(List<HostMetricsSnapshotEntity> entities);

    List<HostMetricsSnapshotDto> toDtoPage(Page<HostMetricsSnapshotEntity> entityPage);
}