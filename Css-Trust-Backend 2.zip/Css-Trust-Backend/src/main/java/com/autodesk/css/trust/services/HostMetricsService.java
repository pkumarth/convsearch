package com.autodesk.css.trust.services;



import com.autodesk.css.trust.entitities.dto.HostMetricsSnapshotDto;
import com.autodesk.css.trust.entitities.entity.HostMetricsSnapshotEntity;
import com.autodesk.css.trust.entitities.mapper.HostMetricsMapper;
import com.autodesk.css.trust.repo.HostMetricsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class HostMetricsService {

    @Autowired
    private HostMetricsRepository repository;

    @Autowired
    private HostMetricsMapper mapper;

    public HostMetricsSnapshotEntity createSnapshot(HostMetricsSnapshotDto dto) {
        HostMetricsSnapshotEntity snapshot = mapper.toEntity(dto);
        return repository.save(snapshot);
    }

    public List<HostMetricsSnapshotDto> getDailySnapshots(LocalDateTime date) {
        return mapper.toDtoList(repository.findDailySnapshots(date));
    }

    public List<HostMetricsSnapshotDto> getWeeklySnapshots(LocalDateTime date) {
        return  mapper.toDtoList(repository.findWeeklySnapshots(date));
    }


    public Optional<HostMetricsSnapshotDto> getLatestSnapshot() {
        return Optional.ofNullable(mapper.toDto(repository.findLatestSnapshot() ));
    }

    public List<HostMetricsSnapshotDto> getSnapshotsByDateRange(LocalDateTime start, LocalDateTime end) {
        return mapper.toDtoList(repository.findByTimestampBetween(start, end));
    }


}
