package com.autodesk.css.trust.api;

import com.autodesk.css.trust.common.res.ApiResponse;
import com.autodesk.css.trust.entitities.dto.AgentDto;
import com.autodesk.css.trust.entitities.dto.TaskDto;
import com.autodesk.css.trust.entitities.enums.TaskStatus;
import com.autodesk.css.trust.entitities.models.TaskAddLogRequest;
import com.autodesk.css.trust.entitities.models.TaskStatusUpdateRequest;
import com.autodesk.css.trust.services.AgentService;
import com.autodesk.css.trust.services.TaskCoreUseCase;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/tasks")
public class TaskTrackerCoreController {
    @Autowired
    AgentService agentService;

    @Autowired
    CommonRestUtils commonRestUtils;

    @Autowired
    TaskCoreUseCase taskCoreUseCase;

    @GetMapping("/getTasks")
    public ResponseEntity<ApiResponse> getTasks(@RequestHeader HttpHeaders headers) {
        AgentDto agentDto = commonRestUtils.getAgent(headers);
        if (agentDto == null) {
            ApiResponse response = commonRestUtils.getResponseTemplate(false, 500, "Invalid Credentials", "Invalid Credentials");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        List<TaskDto> tasks = taskCoreUseCase.getTasks(agentDto);
        ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
        response.setResult(CommonRestUtils.listToMap(Collections.singletonList(tasks), "tasks"));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    //def post_task_event(task_id, task_status, task_logs, progressPercentage):
    @PostMapping("/updateStatus")
    public ResponseEntity<ApiResponse> updateTask(@RequestBody TaskStatusUpdateRequest request, @RequestHeader HttpHeaders headers) {
        AgentDto agentDto = commonRestUtils.getAgent(headers);
        if (agentDto == null) {
            ApiResponse response = commonRestUtils.getResponseTemplate(false, 500, "Invalid Credentials", "Invalid Credentials");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        taskCoreUseCase.processStatusUpdate(request, agentDto.getId());

        ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @PostMapping("/completed")
    public ResponseEntity<ApiResponse> taskCompleted(@RequestBody Map<String, Object> inpReq, /*@RequestBody TaskStatusUpdateRequest request,*/ @RequestHeader HttpHeaders headers) throws JsonProcessingException {


        TaskStatusUpdateRequest request = new TaskStatusUpdateRequest();
        request.setTaskId(inpReq.get("taskId").toString());
        request.setResult((Map<String, Object>) inpReq.get("result"));
        request.setStatus(inpReq.get("status").toString());
        request.setLogMessage(inpReq.get("logMessage").toString());

        AgentDto agentDto = commonRestUtils.getAgent(headers);
        if (agentDto == null) {
            ApiResponse response = commonRestUtils.getResponseTemplate(false, 500, "Invalid Credentials", "Invalid Credentials");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        Long taskId = Long.parseLong(request.getTaskId());
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(request.getResult());
        taskCoreUseCase.taskCompleted(agentDto.getId(), taskId, TaskStatus.valueOf(request.getStatus()), request.getLogMessage(), jsonString);// request.getLogMessage(), request.getResult());
        ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @PostMapping("/addTaskLog")
    public ResponseEntity<ApiResponse> addTaskLog(@RequestBody TaskAddLogRequest request, @RequestHeader HttpHeaders headers) {
        AgentDto agentDto = commonRestUtils.getAgent(headers);
        Long taskId = Long.parseLong(request.getTaskId());

        boolean failed = false;

        if (agentDto == null) {
            failed = true;
        } else {
            try {
                taskCoreUseCase.addTaskLog(agentDto.getId(), taskId, request.getMessage(), request.getProgressPercent(), LocalDateTime.now());
                ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
                return new ResponseEntity<>(response, HttpStatus.OK);
            }catch (Exception e) {
                failed = true;
            }
        }
        ApiResponse response = commonRestUtils.getResponseTemplate(false, 500, "Invalid Credentials", "Invalid Credentials");

        return new ResponseEntity<>(response, HttpStatus.OK);
    }


}
