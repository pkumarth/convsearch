package com.autodesk.css.trust.common.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

import java.util.Map;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse {
    private Status status;
    private Map<String, Object> resultMap;
    private Object result;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public class Status {
        private boolean success;
        private Integer code;
        private String message;
        private String cause;


    }
}


