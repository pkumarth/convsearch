package com.autodesk.css.trust.repo;


import com.autodesk.css.trust.entitities.entity.DashQueryMapEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DashQueryMapRepo extends JpaRepository<DashQueryMapEntity, Long> {
    Optional<DashQueryMapEntity> findByObjectIdAndDashboardName(String objectId, String dashboardName);
/*
    @Query(value = "SELECT * FROM sql_statements WHERE LOWER(object_id) = LOWER(:objectId) AND LOWER(dashboard_name) = LOWER(:dashboardName)", nativeQuery = true)
    List<Object[]> findRawQuery(@Param("objectId") String objectId, @Param("dashboardName") String dashboardName);


    @Query(value = "SELECT * FROM sql_statements WHERE  LOWER(dashboard_name) = LOWER(:dashboardName)", nativeQuery = true)
    List<Object[]> findRawQueryDashboard(@Param("dashboardName") String dashboardName);
*/
    Optional<DashQueryMapEntity> findByObjectIdIgnoreCaseAndDashboardNameIgnoreCase(String objectId, String dashboardName);

    List<DashQueryMapEntity> findAllByDashboardNameIgnoreCase(String dashboardName);

}