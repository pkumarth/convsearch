package com.autodesk.css.trust.entitities.models;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class InventoryCreateRequest {
    @NotBlank(message = "Environment is required")
    @Size(min = 2, max = 255, message = "Environment must be between 2 and 255 characters")
    private String environment;
    @NotBlank(message = "Cloud Name is required")
    @Size(min = 2, max = 255, message = "Cloud Name must be between 2 and 255 characters")
    private String cloudType;
    private String accountId;
    private String accountName;
    private String region;//serverLocation
    @NotBlank(message = "Os Type is required")
    @Size(min = 2, max = 255, message = "Os Type must be between 2 and 255 characters")
    private String platform;
    private String instanceId;
    private String instanceCreationDate;
    @NotBlank(message = "Ip is required")
    @Size(min = 7, max = 15, message = "Host Name must be between 7 and 15 characters")
    private String ipAddress;
    // edr and patching status
    private String edrCloudStatus;
    private String edrStatus;
    private String lastPatchDate;
    private String patchStatus;
    private Boolean onboardedToNextGenPatching;//pathchAvailable
    private String HardenedDate;
    private String HardenedStatus;
    // other field from ui
    @NotBlank(message = "Host Name is required")
    @Size(min = 2, max = 255, message = "Host Name must be between 2 and 255 characters")
    private String hostName;
    private String hostStatus;
    private String group;
    @NotBlank(message = "Ssh User is required")
    @Size(min = 2, max = 255, message = "Ssh User must be between 2 and 255 characters")
    private String sshUser;
    private String applicationName;

}
