package com.autodesk.css.trust.entitities.models;

import lombok.Data;

@Data
public class TemplateTaskRequest {
//    private String taskName;
//    private String taskType;
//    private String extraArguments;
    //
    private String description;
    private String executionMode;// onetime ,recurring,ondemand
    private String schedule;
    private String emailNotificationList;
}
