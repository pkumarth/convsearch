package com.autodesk.css.trust.entitities.models;

import lombok.Data;

@Data
public class TaskResultUpdateRequest {
}
