package com.autodesk.css.trust.entitities.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InventoryFilterReqDto {
    private Long inventoryId;
    // filter field
    private String cloudType;
    private String platform;
    private String environment;
    private String edrStatus;
    private String edrHealth;
    private String patchStatus;
    private String accountId;
    private Boolean onboardedToNextGenPatching;
    private Integer page;
    private Integer size;
    private String sortBy;


}
