package com.autodesk.css.trust.repo;

import com.autodesk.css.trust.entitities.dto.InventoryFilterReqDto;
import com.autodesk.css.trust.entitities.entity.InventoryEntity;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.ArrayList;
import java.util.List;


public interface InventoryRepository extends JpaRepository<InventoryEntity, Long>, JpaSpecificationExecutor<InventoryEntity> {

    static Specification<InventoryEntity> withDynamicQuery(InventoryFilterReqDto filter) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (filter.getCloudType() != null) {
                predicates.add(criteriaBuilder.equal(root.get("cloudType"), filter.getCloudType()));
            }

            if (filter.getPlatform() != null) {
                predicates.add(criteriaBuilder.equal(root.get("platform"), filter.getPlatform()));
            }

            if (filter.getEnvironment() != null) {
                predicates.add(criteriaBuilder.equal(root.get("environment"), filter.getEnvironment()));
            }
            if (filter.getEdrStatus() != null) {
                predicates.add(criteriaBuilder.equal(root.get("edrStatus"), filter.getEdrStatus()));
            }

            if (filter.getEdrHealth() != null) {
                predicates.add(criteriaBuilder.equal(root.get("edrHealth"), filter.getEdrHealth()));
            }

            if (filter.getPatchStatus() != null) {
                predicates.add(criteriaBuilder.equal(root.get("patchStatus"), filter.getPatchStatus()));
            }
            if (filter.getAccountId() != null) {
                predicates.add(criteriaBuilder.equal(root.get("accountId"), filter.getAccountId()));
            }

            if (filter.getOnboardedToNextGenPatching() != null) {
                predicates.add(criteriaBuilder.equal(root.get("onboardedToNextGenPatching"), filter.getOnboardedToNextGenPatching()));
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }
}
