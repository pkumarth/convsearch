package com.autodesk.css.trust.api;

import com.autodesk.css.trust.services.TaskService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/task")
@AllArgsConstructor
public class TaskController {
    private TaskService taskService;
    private CommonRestUtils commonRestUtils;
}
