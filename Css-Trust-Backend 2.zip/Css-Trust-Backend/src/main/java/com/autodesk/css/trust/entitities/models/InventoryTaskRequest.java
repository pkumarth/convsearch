package com.autodesk.css.trust.entitities.models;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class InventoryTaskRequest {
    //    private String taskName;
//    private String taskType;
//    private String extraArguments;
    //
    @NotBlank(message = "Environment is required")
    @Size(min = 2, max = 255, message = "Environment must be between 2 and 255 characters")
    private String environment;

    @NotBlank(message = "Cloud Name is required")
    @Size(min = 2, max = 255, message = "Cloud Name must be between 2 and 255 characters")
    private String cloudType;

    @NotBlank(message = "Os Type is required")
    @Size(min = 2, max = 255, message = "Os Type must be between 2 and 255 characters")
    private String platform;

    @NotBlank(message = "Ip is required")
    @Size(min = 7, max = 15, message = "Host Name must be between 7 and 15 characters")
    private String ipAddress;

    @NotBlank(message = "Host Name is required")
    @Size(min = 2, max = 255, message = "Host Name must be between 2 and 255 characters")
    private String hostName;
    private String hostStatus;
    private String group;
    private String authMethod;
    @NotBlank(message = "Ssh User is required")
    @Size(min = 2, max = 255, message = "Ssh User must be between 2 and 255 characters")
    private String sshUser;
    private String applicationName;
    private String serverLocation;



}
