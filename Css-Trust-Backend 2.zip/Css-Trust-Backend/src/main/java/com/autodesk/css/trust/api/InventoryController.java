package com.autodesk.css.trust.api;

import com.autodesk.css.trust.common.res.ApiResponse;
import com.autodesk.css.trust.entitities.dto.InventoryFilterReqDto;
import com.autodesk.css.trust.entitities.dto.InventoryReqDto;
import com.autodesk.css.trust.entitities.dto.InventoryResDto;
import com.autodesk.css.trust.services.InventoryService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/inventory")
@AllArgsConstructor
public class InventoryController {
    private InventoryService inventoryService;
    private CommonRestUtils commonRestUtils;

    @PostMapping("")
    public ResponseEntity<ApiResponse> addInventory(@RequestBody InventoryReqDto request, @RequestHeader HttpHeaders headers) {
        try {
            //request.getAgentId().getId()
            Long agentId = null;
            InventoryResDto inventoryRespDto = inventoryService.addInventory(agentId, request);
            ApiResponse response = commonRestUtils.getResponseTemplate(true, 201, "Successfully Done!", "Successfully Done!", inventoryRespDto);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            ApiResponse response = commonRestUtils.getResponseTemplate(false, 422, "Invalid Credentials", "Invalid Credentials");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }

    @PostMapping("/_bulk")
    public ResponseEntity<ApiResponse> addAllInventory(@RequestBody List<InventoryReqDto> requestDtoList, @RequestHeader HttpHeaders headers) {
        try {
            //request.getAgentId().getId()
            Long agentId = null;
            List<InventoryResDto> inventoryRespDtoList = inventoryService.addInventory(agentId, requestDtoList);
            ApiResponse response = commonRestUtils.getResponseTemplate(true, 201, "Successfully Done!", "Successfully Done!", inventoryRespDtoList);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            ApiResponse response = commonRestUtils.getResponseTemplate(false, 422, "Invalid Credentials", "Invalid Credentials");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }

    @GetMapping("/{inventoryId}")
    public ResponseEntity<ApiResponse> findInventory(@PathVariable Long inventoryId, @RequestHeader HttpHeaders headers) {
        try {
            //request.getAgentId().getId()
            String agentId = null;
            InventoryResDto inventoryRespDto = inventoryService.findInventory(inventoryId);
            ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!", inventoryRespDto);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            ApiResponse response = commonRestUtils.getResponseTemplate(false, 204, "Invalid Credentials", "Invalid Credentials");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }

    @GetMapping("")
    public ResponseEntity<ApiResponse> findAllInventory(@RequestHeader HttpHeaders headers) {
        try {
            //request.getAgentId().getId()
            String agentId = null;
            List<InventoryResDto> inventoryRespDtoList = inventoryService.findAllInventory();
            ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!", inventoryRespDtoList);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            ApiResponse response = commonRestUtils.getResponseTemplate(false, 204, "Invalid Credentials", "Invalid Credentials");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }

    @PostMapping("/search")
    public ResponseEntity<ApiResponse> searchInventory(@RequestBody InventoryFilterReqDto filter, @RequestHeader HttpHeaders headers) {
        if (filter == null) {
            filter = new InventoryFilterReqDto();
        }
        if (filter.getPage() == null) {
            filter.setPage(0);
        }

        if (filter.getSize() == null) {
            filter.setSize(-1);
        }
        List<InventoryResDto> inventoryRespDtoList = inventoryService.searchInventory(filter, filter.getPage(), filter.getSize(), filter.getSortBy());
        ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!", inventoryRespDtoList);
        return ResponseEntity.ok(response);
    }


    @PutMapping("/task/{taskType}/apply")
    public ResponseEntity<ApiResponse> executeInventoryTask(@PathVariable String taskType, @RequestBody List<InventoryFilterReqDto> filteredInventoryList, @RequestHeader HttpHeaders headers) {
        if (filteredInventoryList == null || filteredInventoryList.isEmpty()) {
            ApiResponse response = commonRestUtils.getResponseTemplate(true, 200, "No Task Selected for Patching or EDR", "No Task Selected for Patching or EDR");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        List<InventoryResDto> inventoryRespDtoList = inventoryService.executeInventoryTask(taskType, filteredInventoryList);
        ApiResponse response = commonRestUtils.getResponseTemplate(true, 202, "Task in Progress!", "Task in Progress!", inventoryRespDtoList);
        return new ResponseEntity<>(response, HttpStatus.ACCEPTED);
    }

    @DeleteMapping("/{inventoryId}")
    public ResponseEntity<ApiResponse> removeInventory(@PathVariable Long inventoryId, @RequestHeader HttpHeaders headers) {
        try {
            //request.getAgentId().getId()
            String agentId = null;
            inventoryService.removeInventory(inventoryId);
            ApiResponse response = commonRestUtils.getResponseTemplate(true, 204, "Successfully Done!", "Successfully Done!", "");
            return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            ApiResponse response = commonRestUtils.getResponseTemplate(false, 204, "Invalid Credentials", "Invalid Credentials");
            return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);
        }
    }

}
