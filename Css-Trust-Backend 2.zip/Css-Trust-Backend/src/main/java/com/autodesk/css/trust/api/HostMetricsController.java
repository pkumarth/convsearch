package com.autodesk.css.trust.api;


import com.autodesk.css.trust.common.res.ApiResponse;
import com.autodesk.css.trust.entitities.dto.HostMetricsSnapshotDto;
import com.autodesk.css.trust.services.HostMetricsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@RestController

@RequestMapping("/host-metrics")
public class HostMetricsController {
    @Autowired
    private HostMetricsService hostMetricsUseCase;

    // Get latest snapshot
    @GetMapping("/snapshots/latest")
    public ResponseEntity<ApiResponse> getLatestSnapshot() {
        HostMetricsSnapshotDto dto =  hostMetricsUseCase.getLatestSnapshot().get() ;

        ApiResponse response = CommonRestUtils.getSuccessResponseTemplate();
        response.setResult(CommonRestUtils.pojoToMap(dto));
        return ResponseEntity.ok(response);
    }

    // Get daily snapshots
    @GetMapping("/snapshots/daily")
    public ResponseEntity< ApiResponse> getDailySnapshots(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        List<HostMetricsSnapshotDto> snapshots = hostMetricsUseCase.getDailySnapshots(date);

        ApiResponse response = CommonRestUtils.getSuccessResponseTemplate();
        response.setResult(CommonRestUtils.listToMap(Collections.singletonList(snapshots),"snapshots"));

        return ResponseEntity.ok(response);
    }

    // Get weekly snapshots
    @GetMapping("/snapshots/weekly")
    public ResponseEntity<ApiResponse> getWeeklySnapshots(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        List<HostMetricsSnapshotDto> snapshots = hostMetricsUseCase.getWeeklySnapshots(date);
        ApiResponse response = CommonRestUtils.getSuccessResponseTemplate();
        response.setResult(CommonRestUtils.listToMap(Collections.singletonList(snapshots),"snapshots"));

        return ResponseEntity.ok(response);
    }

}
