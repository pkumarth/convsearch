package com.autodesk.css.trust.common;

public final class ApplicationConstants {

}
