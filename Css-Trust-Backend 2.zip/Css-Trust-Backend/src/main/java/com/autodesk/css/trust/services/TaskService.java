package com.autodesk.css.trust.services;

import com.autodesk.css.trust.entitities.dto.AgentDto;
import com.autodesk.css.trust.entitities.dto.TaskDto;
import com.autodesk.css.trust.entitities.models.TaskCreateRequest;
import com.autodesk.css.trust.entitities.models.TaskFilterRequest;

import java.util.List;

public interface TaskService {
     void addTask(Long agentId, TaskCreateRequest request) throws Exception;
//     List<TaskDto> getTasks(AgentDto agentDto);
     List<TaskDto> searchTask(TaskFilterRequest filter, int page, int size, String sortBy);
}
