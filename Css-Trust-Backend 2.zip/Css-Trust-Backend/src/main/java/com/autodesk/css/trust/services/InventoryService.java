package com.autodesk.css.trust.services;

import com.autodesk.css.trust.entitities.dto.InventoryFilterReqDto;
import com.autodesk.css.trust.entitities.dto.InventoryReqDto;
import com.autodesk.css.trust.entitities.dto.InventoryResDto;
import com.autodesk.css.trust.entitities.models.TaskFilterRequest;

import java.util.List;

public interface InventoryService {
    InventoryResDto addInventory(Long agentId,InventoryReqDto inventoryReqDto);

    List<InventoryResDto> addInventory(Long agentId, List<InventoryReqDto> inventoryReqDtoList);

    InventoryResDto findInventory(Long inventoryId);

    List<InventoryResDto> findAllInventory();

    List<InventoryResDto> searchInventory(InventoryFilterReqDto filter, int page, int size, String sortBy);

    List<InventoryResDto> executeInventoryTask(String taskType, List<InventoryFilterReqDto> filteredInventoryList);

    void removeInventory(Long inventoryId);
}
