package com.autodesk.css.trust.repo;


import com.autodesk.css.trust.entitities.entity.AgentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AgentRepository extends JpaRepository<AgentEntity, Long> {

    AgentEntity findByAgentClientId(String agentClientId);

    List<AgentEntity> findByAgentStatus(String agentStatus);

    @Modifying
    @Query("UPDATE AgentEntity a SET a.agentLastReportedTime = :date WHERE a.agentClientId = :agentId")
    void updateAgentLastLogTime(String agentId, LocalDateTime date);
}
