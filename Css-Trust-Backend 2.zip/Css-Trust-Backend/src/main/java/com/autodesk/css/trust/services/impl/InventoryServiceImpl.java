package com.autodesk.css.trust.services.impl;

import com.autodesk.css.trust.entitities.dto.InventoryFilterReqDto;
import com.autodesk.css.trust.entitities.dto.InventoryReqDto;
import com.autodesk.css.trust.entitities.dto.InventoryResDto;
import com.autodesk.css.trust.entitities.dto.TaskDto;
import com.autodesk.css.trust.entitities.entity.InventoryEntity;
import com.autodesk.css.trust.entitities.entity.TaskEntity;
import com.autodesk.css.trust.entitities.mapper.InventoryMapper;
import com.autodesk.css.trust.repo.InventoryRepository;
import com.autodesk.css.trust.repo.TaskRepository;
import com.autodesk.css.trust.services.InventoryService;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class InventoryServiceImpl implements InventoryService {
    private InventoryRepository inventoryRepository;
    private InventoryMapper inventoryMapper;


    public InventoryEntity addInventoryHelper(Long agentId, InventoryReqDto request) {
//        AgentEntity agentEntity = agentRepository.findById(request.getAgentId()).orElse(null);
//        if (agentEntity == null) {
//            throw new Exception("Agent not found!");
//        }
        InventoryEntity inventoryEntity = new InventoryEntity();
//        inventoryEntity.setAgent(agentEntity);
//        inventoryEntity.setTaskStatus(TaskStatus.QUEUED.name());
        inventoryEntity.setEnvironment(request.getEnvironment());
        inventoryEntity.setCloudType(request.getCloudType() == null ? "AWS" : request.getCloudType());
        inventoryEntity.setRegion(request.getRegion());
        inventoryEntity.setAccountId(request.getAccountId());
        inventoryEntity.setAccountName(request.getAccountName());
        inventoryEntity.setInstanceId(request.getInstanceId());
        inventoryEntity.setInstanceType(request.getInstanceType());
        inventoryEntity.setIpAddress(request.getIpAddress());
        inventoryEntity.setInstanceCreationDate(request.getInstanceCreationDate());
        inventoryEntity.setPlatform(request.getPlatform());
        // default value field
        inventoryEntity.setEdrStatus("N/A");
        inventoryEntity.setEdrHealth(" N/A");
        inventoryEntity.setLastEdrInstallationTime(null);
        inventoryEntity.setNexScheduledEdrInstallationTime(null);
        inventoryEntity.setEdrScheduledBy(null);
        inventoryEntity.setPatchStatus("N/A");
        inventoryEntity.setOnboardedToNextGenPatching(Boolean.FALSE);
        inventoryEntity.setLastPatchInstallationTime(null);
        inventoryEntity.setNexScheduledPatchInstallationTime(null);
        inventoryEntity.setPatchScheduledBy(null);
        // save it
        return inventoryEntity;

    }


    @Override
    public InventoryResDto addInventory(Long agentId, InventoryReqDto inventoryReqDto) {
        InventoryEntity rawEntity = addInventoryHelper(agentId, inventoryReqDto);
        InventoryEntity savedEntity = inventoryRepository.save(rawEntity);
        return inventoryMapper.toInventoryResDto(savedEntity);
    }

    @Override
    public List<InventoryResDto> addInventory(Long agentId, List<InventoryReqDto> inventoryReqDtoList) {
        List<InventoryResDto> resDtos = new ArrayList<>();
        for (InventoryReqDto inventoryReqDto : inventoryReqDtoList) {
            InventoryResDto resDto = addInventory(agentId, inventoryReqDto);
            resDtos.add(resDto);
        }
        return resDtos;
    }

    @Override
    public InventoryResDto findInventory(Long inventoryId) {
        Optional<InventoryEntity> savedEntityOpt = inventoryRepository.findById(inventoryId);
        InventoryEntity savedEntity = savedEntityOpt.orElse(null);
        return inventoryMapper.toInventoryResDto(savedEntity);
    }

    @Override
    public List<InventoryResDto> findAllInventory() {
        List<InventoryEntity> savedEntities = inventoryRepository.findAll();
        return inventoryMapper.toDtoList(savedEntities);
    }

    @Override
    public List<InventoryResDto> searchInventory(InventoryFilterReqDto filter, int page, int size, String sortBy) {
        Sort sort = Sort.by(sortBy != null ? sortBy : "inventoryId");
        List<InventoryResDto> list = new ArrayList<>();
        if (page < 0 || size < 0) {
            List<InventoryEntity> entityList = inventoryRepository.findAll(
                    InventoryRepository.withDynamicQuery(filter),
                    sort
            );
            list = inventoryMapper.toDtoList(entityList);
        } else {
            Page<InventoryEntity> res;
            PageRequest pageRequest = PageRequest.of(page, size, sort);
            res = inventoryRepository.findAll(
                    InventoryRepository.withDynamicQuery(filter),
                    pageRequest
            );
            list = inventoryMapper.toDtoPage(res);
        }
        return list;
    }

    @Override
    public void removeInventory(Long inventoryId) {
        inventoryRepository.deleteAllById(Collections.singleton(inventoryId));
    }

    @Override
    public List<InventoryResDto> executeInventoryTask(String taskType, List<InventoryFilterReqDto> filteredInventoryList) {
        // write Logic latter on
        return List.of();
    }
}
