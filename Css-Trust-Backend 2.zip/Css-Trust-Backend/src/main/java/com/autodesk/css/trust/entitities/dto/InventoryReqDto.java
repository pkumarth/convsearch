package com.autodesk.css.trust.entitities.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.TimeZone;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InventoryReqDto {
    private Long inventoryId;

    private String environment;

    private String cloudType;

    private String region;

    private String accountId;

    private String accountName;

    private String instanceId;

    private String instanceType;

    private String ipAddress;

    @JsonFormat( pattern = "yyyy-MM-dd")
    private LocalDate instanceCreationDate;

    private String platform;

    //inventory status

//    private String edrStatus;
//
//    private String edrHealth;

//    private LocalDateTime lastEdrInstallationTime;
//
//    private LocalDateTime nexScheduledEdrInstallationTime;

//    private String edrScheduledBy;
//
//    private String patchStatus;

//    private Boolean onboardedToNextGenPatching;
//
//    @JsonFormat( pattern = "dd-MM-yyyy'T'HH:mm")
//    private LocalDateTime lastPatchInstallationTime;

//    private LocalDateTime nexScheduledPatchInstallationTime;

//    private String patchScheduledBy;
}
