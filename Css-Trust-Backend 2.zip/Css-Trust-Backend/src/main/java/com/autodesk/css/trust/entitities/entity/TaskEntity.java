package com.autodesk.css.trust.entitities.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "Task_Master")
public class TaskEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JoinColumn(name = "task_id")
    private Long taskId;

    @Column(nullable = false, name = "task_name")
    private String taskName;

    @Column(name = "task_type")
    private String taskType;

    @Column(name = "task_subtype")
    private String taskSubType;

    // @Lob
    @Column(columnDefinition = "TEXT")
    private String taskInput;

    @Column(name = "extra_arguments")
    private String extraArguments;

    @Column(name = "scheduling_type")
    private String schedulingType;

    @Column(name = "schedule")
    private String schedule;

    @Column(name = "parent_task_id")
    private Long parentTaskId;

    @Column(name = "task_trigger_time")
    private LocalDateTime taskTriggerTime;

    @Column(name = "task_creation_time")
    private LocalDateTime taskCreationTime;

    @Column(name = "notification_list", columnDefinition = "TEXT")
    private String notificationList;

    //@Lob
    @Column(columnDefinition = "TEXT")
    private String taskTags; // Consider using a suitable data structure like a List or Set

    // result storage
    @Column(nullable = false)
    private String taskStatus;

    @Column(name = "progress")
    private Integer progress;

    @Column(name = "task_exec_start_time")
    private LocalDateTime taskExecStartTime;

    @Column(name = "task_exec_end_time")
    private LocalDateTime taskExecEndTime;

    @Column(name = "task_result", columnDefinition = "TEXT")
    private String taskResult;

    @ManyToOne
    @JoinColumn(name = "Task_Agent_Id")
    private AgentEntity agent;

//    //    @Lob
//    @Column(columnDefinition = "TEXT")
//    private String taskLogs; // Consider using a suitable data structure like a List or Set

//    @Column(name = "created_by")
//    private String createdBy;
//
//    @Column(name = "updated_by")
//    private String updatedBy;
//
//    @Column(name = "created_dt")
//    private String createdDt;
//
//    @Column(name = "updated_dt")
//    private String updatedDt;


}
