package com.autodesk.css.trust.entitities.mapper;



import com.autodesk.css.trust.entitities.dto.TaskLogDto;
import com.autodesk.css.trust.entitities.entity.TaskLogEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface TaskLogMapper {

    TaskLogMapper INSTANCE = Mappers.getMapper(TaskLogMapper.class);

    TaskLogEntity toTaskLogEntity(TaskLogDto taskLogDto);

    TaskLogDto toTaskLogDto(TaskLogEntity taskLogEntity);

    List<TaskLogDto> toDtoList(List<TaskLogEntity> entities);
}
