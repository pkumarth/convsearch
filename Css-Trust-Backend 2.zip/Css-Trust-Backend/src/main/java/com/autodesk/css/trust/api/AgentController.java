package com.autodesk.css.trust.api;

import com.autodesk.css.trust.common.res.ApiResponse;
import com.autodesk.css.trust.entitities.dto.AgentDto;
import com.autodesk.css.trust.services.AgentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/agentcore/")
public class AgentController {
    @Autowired
    AgentService agentService;

    @Autowired
    CommonRestUtils commonRestUtils;

    @GetMapping("/heartbeat")
    public ResponseEntity<ApiResponse> updateAgent(@RequestHeader HttpHeaders headers){

        AgentDto agentDto = commonRestUtils.getAgent(headers);

        if(agentDto!=null){
            agentService.updateAgentLastLogTime(agentDto , LocalDateTime.now());
            ApiResponse response = new ApiResponse();
//            response.setSuccess(true);
//            response.setMessage("Successfully updated the agent");
//            response.setCode(200);
//            response.setCause("Successfully updated the agent");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }

        ApiResponse response = new ApiResponse();
//        response.setSuccess(false);
//        response.setMessage("Update Failed");
//        response.setCode(500);
//        response.setCause("Update Failed");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /*
    @PostMapping("/myEndpoint")
    public ResponseEntity<String> myEndpoint(@RequestHeader HttpHeaders headers, @RequestBody TaskResultUpdateRequest request) {
        String clientId = headers.getFirst("client-id");
        String clientSecret = headers.getFirst("client-secret");

        // Access the request body
        String dataFromBody = request.getData();

        // Use clientId, clientSecret, and dataFromBody for your logic
        // ...

        return ResponseEntity.status(HttpStatus.OK).body("Request received with client-id: " + clientId +
                ", client-secret: " + clientSecret + " and data: " + dataFromBody);
    }*/


}
