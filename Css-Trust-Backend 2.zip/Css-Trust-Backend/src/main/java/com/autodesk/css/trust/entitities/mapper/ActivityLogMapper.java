package com.autodesk.css.trust.entitities.mapper;



import com.autodesk.css.trust.entitities.dto.ActivityLogDto;
import com.autodesk.css.trust.entitities.entity.ActivityLogEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface ActivityLogMapper {

    ActivityLogMapper INSTANCE = Mappers.getMapper(ActivityLogMapper.class);

    ActivityLogEntity toActivityLogEntity(ActivityLogDto activityLogDto);

    ActivityLogDto toActivityLogDto(ActivityLogEntity activityLogEntity);
}