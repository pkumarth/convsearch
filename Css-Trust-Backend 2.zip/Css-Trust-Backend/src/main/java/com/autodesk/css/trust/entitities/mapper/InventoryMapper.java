package com.autodesk.css.trust.entitities.mapper;



import com.autodesk.css.trust.entitities.dto.InventoryReqDto;
import com.autodesk.css.trust.entitities.dto.InventoryResDto;
import com.autodesk.css.trust.entitities.dto.TaskDto;
import com.autodesk.css.trust.entitities.entity.InventoryEntity;
import com.autodesk.css.trust.entitities.entity.TaskEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.data.domain.Page;

import java.util.List;

@Mapper(componentModel = "spring")
public interface InventoryMapper {

    InventoryMapper INSTANCE = Mappers.getMapper(InventoryMapper.class);

    InventoryEntity toInventoryEntity(InventoryReqDto inventoryReqDto);

    InventoryResDto toInventoryResDto(InventoryEntity inventoryEntity);

    List<InventoryResDto> toDtoList(List<InventoryEntity> entities);

    List<InventoryResDto> toDtoPage(Page<InventoryEntity> entityPage);
}