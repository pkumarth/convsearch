package com.autodesk.css.trust.entitities.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "Inventory_Master")
public class InventoryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JoinColumn(name = "inventory_id")
    private Long inventoryId;

    @Column(nullable = false, name = "environment")
    private String environment;

    @Column(nullable = false, name = "cloud_type")
    private String cloudType;

    @Column( name = "region")
    private String region;

    @Column(nullable = false, name = "account_id")
    private String accountId;

    @Column(nullable = false, name = "account_name")
    private String accountName;

    @Column(nullable = false, name = "instance_id")
    private String instanceId;

    @Column( name = "instance_type")
    private String instanceType;

    @Column(nullable = false, name = "ip_address",unique = true)
    private String ipAddress;

    @Column(name = "instance_creation_dt")
    private LocalDate instanceCreationDate;

    @Column(nullable = false, name = "platform")
    private String platform;

    //inventory status
    @Column(nullable = false, name = "edr_status")
    private String edrStatus; // 'N/A' , 'EDR Installed' 'EDR Not Installed'

    @Column(nullable = false, name = "edr_health")
    private String edrHealth;   // N/A EDR Not Installed Reporting to EDR Cloud

    @Column(name = "last_edr_installation_time")
    private LocalDateTime lastEdrInstallationTime;

    @Column(name = "next_scheduled_edr_installation_time")
    private LocalDateTime nexScheduledEdrInstallationTime;

    @Column(name = "edr_scheduled_by")
    private String edrScheduledBy;

    @Column(nullable = false, name = "patch_status")
    private String patchStatus; // N/A Patches Found No Patches

    @Column(nullable = false, name = "onboarded_to_next_gen_patching")
    private Boolean onboardedToNextGenPatching;

    @Column(name = "last_patch_installation_time")
    private LocalDateTime lastPatchInstallationTime;

    @Column(name = "next_scheduled_patch_installation_time")
    private LocalDateTime nexScheduledPatchInstallationTime;

    @Column(name = "patch_scheduled_by")
    private String patchScheduledBy;



//    @Column(name = "created_by")
//    private String createdBy;
//
//    @Column(name = "updated_by")
//    private String updatedBy;
//
//    @Column(name = "created_dt")
//    private String createdDt;
//
//    @Column(name = "updated_dt")
//    private String updatedDt;


}
