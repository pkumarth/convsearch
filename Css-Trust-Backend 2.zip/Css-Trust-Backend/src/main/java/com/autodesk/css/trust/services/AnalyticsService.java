package com.autodesk.css.trust.services;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AnalyticsService {

    private final JdbcTemplate analyticsJdbcTemplate;

    public AnalyticsService(JdbcTemplate analyticsJdbcTemplate) {
        this.analyticsJdbcTemplate = analyticsJdbcTemplate;
    }

    public List<Map<String, Object>> fetchAnalyticsData(String sqlQuery, Map<String, String> params) {

        for (Map.Entry<String, String> entry : params.entrySet()) {
            if(entry.getKey().equalsIgnoreCase("$account_id") && sqlQuery.contains(entry.getKey()) ) {
                sqlQuery = replaceAccountId(sqlQuery, entry.getValue());
            }else {
                sqlQuery = sqlQuery.replace(entry.getKey(), entry.getValue());
            }
        }

        try {
            List<Map<String, Object>> ret =  analyticsJdbcTemplate.queryForList(sqlQuery);
            return ret;
        } catch (Exception e) {
            System.out.println("Error : "+sqlQuery);
            throw new RuntimeException(e);
        }
    }

    private String replaceAccountId(String sqlQuery, String accountIdRaw) {
        List<String> accountIds = null;
        String accountIdReplacement;

        if ( ObjectUtils.isEmpty(accountIdRaw)) {
            accountIdRaw = "";
        }else{
            accountIds = Arrays.asList(accountIdRaw.split(","));
        }

        if (accountIds == null || accountIds.isEmpty()) {
            accountIdReplacement = "''"; // Empty string to satisfy COALESCE condition
        } else {
            accountIdReplacement = accountIds.stream()
                    .map(id -> "'" + id + "'") // Wrap each ID in single quotes
                    .collect(Collectors.joining(", "));
        }
        sqlQuery = sqlQuery.replace("account_id in ($account_id)", " (COALESCE($account_id, '') = '' OR account_id IN ($account_id)) ");
        return sqlQuery.replace("$account_id", accountIdReplacement);
    }



}
