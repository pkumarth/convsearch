package com.autodesk.css.trust.common.ex;


import com.autodesk.css.trust.common.res.ApiResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.AccessDeniedException;
//import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.nio.file.AccessDeniedException;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
    private static ApiResponse.Status getStatus(boolean success, Integer code, String message, String cause) {
        ApiResponse.Status status = new ApiResponse().new Status();
        status.setSuccess(success);
        status.setMessage(message);
        status.setCode(code);
        status.setCause(cause);
        return status;
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<?> handleResourceNotFoundException(ResourceNotFoundException ex) {
        ApiResponse response = new ApiResponse();
        ApiResponse.Status status = getStatus(false, HttpStatus.NOT_FOUND.value(), "ResourceNotFoundException", ex.getMessage());
        response.setStatus(status);
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<?> handleBadRequestException(BadRequestException ex) {
        ApiResponse response = new ApiResponse();
        ApiResponse.Status status = getStatus(false, HttpStatus.BAD_REQUEST.value(), "BadRequestException", ex.getMessage());
        response.setStatus(status);
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex,
            HttpHeaders headers,
            HttpStatusCode status,
            WebRequest request) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        ApiResponse response = new ApiResponse();
        ApiResponse.Status error = getStatus(false, HttpStatus.BAD_REQUEST.value(), "BadRequestException", errors.toString());
        response.setStatus(error);
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<?> handleAccessDeniedException(AccessDeniedException ex) {
        ApiResponse response = new ApiResponse();
        ApiResponse.Status error = getStatus(false, HttpStatus.FORBIDDEN.value(), "Access Denied", String.valueOf(HttpStatus.FORBIDDEN.value()));
        response.setStatus(error);
        return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
    }

//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<?> handleGlobalException(Exception ex) {
////        ApiResponse apiResponse = new ApiResponse(false, "An unexpected error occurred");
//
//
//        ApiResponse restResponse = new ApiResponse();
//        restResponse.setSuccess(false);
//        restResponse.setMessage("Server Error");
//        restResponse.setCause(ex.getMessage());
//        restResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
//        return new ResponseEntity<>(restResponse, HttpStatus.OK);
//
////        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
//    }
//    @ExceptionHandler(BadCredentialsException.class)
//    @ResponseStatus(HttpStatus.UNAUTHORIZED)
//    public ResponseEntity<?> handleBadCredentials(BadCredentialsException ex) {
//
//        /*ApiResponse restResponse = new ApiResponse();
//        restResponse.setMessage("Authentication failed");
//        restResponse.setCause("Bad credentials");
//        restResponse.setCode(401);*/
//
//        ApiResponse restResponse = new ApiResponse();
//        restResponse.setSuccess(false);
//        restResponse.setMessage("Authentication failed");
//        restResponse.setCause("Bad Credentials");
//        restResponse.setCode(HttpStatus.UNAUTHORIZED.value());
//        return new ResponseEntity<>(restResponse, HttpStatus.UNAUTHORIZED);
//
////        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Bad credentials");
//    }
}