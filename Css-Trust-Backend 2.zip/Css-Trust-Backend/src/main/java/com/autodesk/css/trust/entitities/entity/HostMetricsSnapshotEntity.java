package com.autodesk.css.trust.entitities.entity;


import jakarta.persistence.*;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "host_metrics_snapshot")
@Data
@RequiredArgsConstructor
public class HostMetricsSnapshotEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private LocalDateTime timestamp;

    private Integer totalHosts;
    private Integer totalLinuxHosts;
    private Integer totalMacHosts;
    private Integer totalWindowsHosts;

    private Integer linuxHostWithoutEdr;
    private Integer linuxHostWithEdr;
    private Integer macHostWithoutEdr;
    private Integer macHostWithEdr;
    private Integer windowsHostWithoutEdr;
    private Integer windowsHostWithEdr;

    private Integer hostsWithEdr;
    private Integer hostsWithoutEdr;

    private Integer linuxHostUnhealthyEdr;
    private Integer macHostUnhealthyEdr;
    private Integer windowsHostUnhealthyEdr;
    private Integer hostsWithUnhealthyEdr;

    private Integer attemptedHostPatching;
    private Integer successfulHostPatching;
    private Integer failedHostPatching;

    @Column(columnDefinition = "TEXT")
    private String raw;
}
