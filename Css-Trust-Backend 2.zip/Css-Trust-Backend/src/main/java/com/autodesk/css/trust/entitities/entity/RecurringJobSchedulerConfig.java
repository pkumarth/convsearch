package com.autodesk.css.trust.entitities.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "reoccurring_job_scheduler_config")
public class RecurringJobSchedulerConfig {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JoinColumn(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "Task_Id")
    private TaskEntity task;

    @Column(name = "schedule")
    private String schedule;

    @Column(name = "task_scheduled_start_time")
    private LocalDateTime taskScheduledStartTime;

    @Column(name = "task_scheduled_end_time")
    private LocalDateTime taskScheduledEndTime;

    @Column(name = "job_info", columnDefinition = "TEXT")
    private String jobInfo;
}
