package com.autodesk.css.trust.entitities.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InventoryResDto {
    private Long inventoryId;

    private String cloudType;

    private String environment;

    private String accountId;

    private String accountName;

    private String instanceId;

    private String ipAddress;

    private String platform;

    private String edrStatus;

    private String edrHealth;

    private String patchStatus;

    private LocalDateTime lastPatchInstallationTime;

    private Boolean onboardedToNextGenPatching;
}
