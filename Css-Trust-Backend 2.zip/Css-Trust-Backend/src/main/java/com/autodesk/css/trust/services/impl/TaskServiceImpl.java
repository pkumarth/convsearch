package com.autodesk.css.trust.services.impl;

import com.autodesk.css.trust.entitities.dto.AgentDto;
import com.autodesk.css.trust.entitities.dto.TaskDto;
import com.autodesk.css.trust.entitities.entity.AgentEntity;
import com.autodesk.css.trust.entitities.entity.TaskEntity;
import com.autodesk.css.trust.entitities.enums.TaskStatus;
import com.autodesk.css.trust.entitities.mapper.TaskMapper;
import com.autodesk.css.trust.entitities.models.TaskCreateRequest;
import com.autodesk.css.trust.entitities.models.TaskFilterRequest;
import com.autodesk.css.trust.repo.TaskRepository;
import com.autodesk.css.trust.services.TaskService;
import com.autodesk.css.trust.util.TaskHelper;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class TaskServiceImpl implements TaskService {

    private TaskRepository taskRepository;
    private TaskMapper taskMapper;

    @Override
    public void addTask(Long agentId, TaskCreateRequest request) throws Exception {

//        AgentEntity agentEntity = agentRepository.findById(request.getAgentId()).orElse(null);
//        if (agentEntity == null) {
//            throw new Exception("Agent not found!");
//        }
//        taskEntity.setAgent(agentEntity);
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskName(request.getTaskName());
        taskEntity.setTaskType(request.getTaskType());
        taskEntity.setTaskSubType(request.getTaskSubType());
        taskEntity.setTaskTags(" ");//TODO request.getTaskTags()

//        String hardCodedText = """
//                {
//                            "template": "ewogICJwbGF5Ym9vayI6ICIvYW5zaWJsZS9wbGF5Ym9va3MvbWFjX3VwZGF0ZXMueW1sIiwKICAiaW52ZW50b3J5IjogIi9hbnNpYmxlL3BsYXlib29rcy9tYWNfaW52ZW50b3J5LmluaSIsCiAgImV4dHJhX3ZhcnMiOiAidGFyZ2V0X2hvc3RzPWFsbCIgLAogICJwb3N0cnVuX3NjcmlwdCIgOiAicG9zdHByb2Nlc3NfZGVmYXVsdC5weSIsCiAgInBvc3RydW5fc2NyaXB0X2FyZ3MiIDogWwoJICB7CgkJICAibm9uZSI6Im5vbmUiCgkgIH0KICBdLAogICJkZWJ1ZyIgOiB0cnVlCn0K",
//                            "inventory": "W21hY29zX2hvc3RzXQptYWNvc19ob3N0IGFuc2libGVfaG9zdD0xMC4xMDguOTMuMjA5IGFuc2libGVfY29ubmVjdGlvbj1zc2ggYW5zaWJsZV91c2VyPWVjMi11c2VyIGFuc2libGVfYmVjb21lPXllcyBhbnNpYmxlX3NzaF9wcml2YXRlX2tleV9maWxlPS4va2V5cy9tYWNvcy5wZW0KClthbGw6dmFyc10KYW5zaWJsZV9zc2hfY29tbW9uX2FyZ3M9Jy1vIFN0cmljdEhvc3RLZXlDaGVja2luZz1ubycK",
//                            "trigger": "mac_update",
//                            "taskid": 1,
//                            "eargs": null
//                          }
//                """;

        taskEntity.setTaskStatus(TaskStatus.QUEUED.name());
        taskEntity.setTaskInput(TaskHelper.extractAndEncode(request.getTaskInput()));

//        taskEntity.setTaskInput(hardCodedText);
        // taskEntity.setTaskLogs("");
        taskEntity.setProgress(0);
        TaskEntity saved = taskRepository.save(taskEntity);
        return;

    }


//    @Override
//    public List<TaskDto> getTasks(AgentDto agentDto) {
//        // this method is duplicate of searchTask  , will remove later on  and merge with searchTask
//        Long agentId = agentDto.getId();
//        String status = TaskStatus.QUEUED.name();
//        //List<TaskEntity> entityList = taskRepository.findByAgent_IdAndTaskStatus(id, status);
//        List<TaskEntity> entityList = taskRepository.findByTaskStatus(status);
//        List<TaskDto> taskDtoList = new ArrayList<>();
//        for (TaskEntity taskEntity : entityList) {
//            TaskDto taskDto = taskMapper.toTaskDto(taskEntity);
//            taskDtoList.add(taskDto);
//        }
//        return taskDtoList;
//    }

    @Override
    public List<TaskDto> searchTask(TaskFilterRequest filter, int page, int size, String sortBy) {
        Sort sort = Sort.by(sortBy != null ? sortBy : "taskId");
        List<TaskDto> list;
        if (page < 0 || size < 0) {
            List<TaskEntity> entityList = taskRepository.findAll(
                    TaskRepository.withDynamicQuery(filter),
                    sort
            );
            list = taskMapper.toDtoList(entityList);
        } else {
            Page<TaskEntity> res;
            PageRequest pageRequest = PageRequest.of(page, size, sort);
            res = taskRepository.findAll(
                    TaskRepository.withDynamicQuery(filter),
                    pageRequest
            );
            list = taskMapper.toDtoPage(res);
        }
        return list;
    }
}
