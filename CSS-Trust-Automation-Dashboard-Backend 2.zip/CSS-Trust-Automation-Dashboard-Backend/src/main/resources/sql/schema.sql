--
-- PostgreSQL database dump
--

-- Dumped from database version 14.15 (Ubuntu 14.15-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.15 (Ubuntu 14.15-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.activity_log (
                                     id bigint NOT NULL,
                                     actor_id bigint,
                                     actor_type character varying(255),
                                     date_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
                                     action character varying(255),
                                     action_details character varying(255)
);


ALTER TABLE public.activity_log OWNER TO vrathi;

--
-- Name: activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: vrathi
--

CREATE SEQUENCE public.activity_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activity_log_id_seq OWNER TO vrathi;

--
-- Name: activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vrathi
--

ALTER SEQUENCE public.activity_log_id_seq OWNED BY public.activity_log.id;


--
-- Name: agent_master; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.agent_master (
                                     id bigint NOT NULL,
                                     agent_name character varying(255) NOT NULL,
                                     agent_client_id character varying(255) NOT NULL,
                                     agent_secret character varying(255) NOT NULL,
                                     agent_status character varying(255) DEFAULT 'ACTIVE'::character varying,
                                     agent_lastreportedtime timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
                                     agent_last_reported_time timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.agent_master OWNER TO vrathi;

--
-- Name: agent_master_id_seq; Type: SEQUENCE; Schema: public; Owner: vrathi
--

CREATE SEQUENCE public.agent_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agent_master_id_seq OWNER TO vrathi;

--
-- Name: agent_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vrathi
--

ALTER SEQUENCE public.agent_master_id_seq OWNED BY public.agent_master.id;


--
-- Name: host_metrics_snapshot; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.host_metrics_snapshot (
                                              id bigint NOT NULL,
                                              "timestamp" timestamp without time zone NOT NULL,
                                              total_hosts integer NOT NULL,
                                              total_linux_hosts integer NOT NULL,
                                              total_mac_hosts integer NOT NULL,
                                              total_windows_hosts integer NOT NULL,
                                              linux_host_without_edr integer NOT NULL,
                                              linux_host_with_edr integer NOT NULL,
                                              mac_host_without_edr integer NOT NULL,
                                              mac_host_with_edr integer NOT NULL,
                                              windows_host_without_edr integer NOT NULL,
                                              windows_host_with_edr integer NOT NULL,
                                              hosts_with_edr integer NOT NULL,
                                              hosts_without_edr integer NOT NULL,
                                              linux_host_unhealthy_edr integer NOT NULL,
                                              mac_host_unhealthy_edr integer NOT NULL,
                                              windows_host_unhealthy_edr integer NOT NULL,
                                              hosts_with_unhealthy_edr integer NOT NULL,
                                              attempted_host_patching integer NOT NULL,
                                              successful_host_patching integer NOT NULL,
                                              failed_host_patching integer NOT NULL,
                                              raw text
);


ALTER TABLE public.host_metrics_snapshot OWNER TO vrathi;

--
-- Name: host_metrics_snapshot_id_seq; Type: SEQUENCE; Schema: public; Owner: vrathi
--

CREATE SEQUENCE public.host_metrics_snapshot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.host_metrics_snapshot_id_seq OWNER TO vrathi;

--
-- Name: host_metrics_snapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vrathi
--

ALTER SEQUENCE public.host_metrics_snapshot_id_seq OWNED BY public.host_metrics_snapshot.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.roles (
                              id uuid DEFAULT gen_random_uuid() NOT NULL,
                              name character varying(255) NOT NULL,
                              description character varying(255),
                              permissions character varying(255),
                              created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO vrathi;

--
-- Name: task_logs; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.task_logs (
                                  task_log_id bigint NOT NULL,
                                  task_id bigint,
                                  log_datetime timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
                                  log_message text,
                                  progress_percentage integer,
                                  log_date_time timestamp(6) without time zone NOT NULL,
                                  CONSTRAINT task_logs_progress_percentage_check CHECK (((progress_percentage >= 0) AND (progress_percentage <= 100)))
);


ALTER TABLE public.task_logs OWNER TO vrathi;

--
-- Name: task_logs_task_log_id_seq; Type: SEQUENCE; Schema: public; Owner: vrathi
--

CREATE SEQUENCE public.task_logs_task_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_logs_task_log_id_seq OWNER TO vrathi;

--
-- Name: task_logs_task_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vrathi
--

ALTER SEQUENCE public.task_logs_task_log_id_seq OWNED BY public.task_logs.task_log_id;


--
-- Name: task_master; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.task_master (
                                    task_id bigint NOT NULL,
                                    task_name character varying(255) NOT NULL,
                                    task_type character varying(255),
                                    task_subtype character varying(255),
                                    task_tags text,
                                    task_input text,
                                    task_agent_id bigint,
                                    task_status character varying(255) DEFAULT 'PENDING'::character varying,
                                    task_logs text,
                                    progress integer DEFAULT 0,
                                    task_sub_type character varying(255),
                                    task_result text,
                                    task_start_time timestamp without time zone,
                                    task_end_time timestamp without time zone,
                                    CONSTRAINT task_master_progress_check CHECK (((progress >= 0) AND (progress <= 100)))
);


ALTER TABLE public.task_master OWNER TO vrathi;

--
-- Name: task_master_task_id_seq; Type: SEQUENCE; Schema: public; Owner: vrathi
--

CREATE SEQUENCE public.task_master_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_master_task_id_seq OWNER TO vrathi;

--
-- Name: task_master_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vrathi
--

ALTER SEQUENCE public.task_master_task_id_seq OWNED BY public.task_master.task_id;


--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.user_profiles (
                                      id uuid DEFAULT gen_random_uuid() NOT NULL,
                                      user_id uuid,
                                      email character varying(255) NOT NULL,
                                      first_name character varying(50),
                                      last_name character varying(50),
                                      profile_picture_url character varying(255),
                                      phone_number character varying(20),
                                      bio text,
                                      created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
                                      updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_profiles OWNER TO vrathi;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.user_roles (
                                   user_id uuid NOT NULL,
                                   role_id uuid NOT NULL
);


ALTER TABLE public.user_roles OWNER TO vrathi;

--
-- Name: users; Type: TABLE; Schema: public; Owner: vrathi
--

CREATE TABLE public.users (
                              id uuid DEFAULT gen_random_uuid() NOT NULL,
                              username character varying(255) NOT NULL,
                              password character varying(255) NOT NULL,
                              enabled boolean DEFAULT true,
                              created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
                              updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO vrathi;

--
-- Name: activity_log id; Type: DEFAULT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.activity_log ALTER COLUMN id SET DEFAULT nextval('public.activity_log_id_seq'::regclass);


--
-- Name: agent_master id; Type: DEFAULT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.agent_master ALTER COLUMN id SET DEFAULT nextval('public.agent_master_id_seq'::regclass);


--
-- Name: host_metrics_snapshot id; Type: DEFAULT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.host_metrics_snapshot ALTER COLUMN id SET DEFAULT nextval('public.host_metrics_snapshot_id_seq'::regclass);


--
-- Name: task_logs task_log_id; Type: DEFAULT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_logs ALTER COLUMN task_log_id SET DEFAULT nextval('public.task_logs_task_log_id_seq'::regclass);


--
-- Name: task_master task_id; Type: DEFAULT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_master ALTER COLUMN task_id SET DEFAULT nextval('public.task_master_task_id_seq'::regclass);


--
-- Data for Name: activity_log; Type: TABLE DATA; Schema: public; Owner: vrathi
--

COPY public.activity_log (id, actor_id, actor_type, date_time, action, action_details) FROM stdin;
\.


--
-- Data for Name: agent_master; Type: TABLE DATA; Schema: public; Owner: vrathi
--

COPY public.agent_master (id, agent_name, agent_client_id, agent_secret, agent_status, agent_lastreportedtime, agent_last_reported_time) FROM stdin;
2	adsktest	555	$2a$10$96iz6MZjIZ3QKFhietGqKO4/GGFu5hoQsXturC8wbZlOUeZRfq3vS	enabled	2025-01-24 15:54:24.235408+00	2025-01-24 21:31:35.475563
\.


--
-- Data for Name: host_metrics_snapshot; Type: TABLE DATA; Schema: public; Owner: vrathi
--

COPY public.host_metrics_snapshot (id, "timestamp", total_hosts, total_linux_hosts, total_mac_hosts, total_windows_hosts, linux_host_without_edr, linux_host_with_edr, mac_host_without_edr, mac_host_with_edr, windows_host_without_edr, windows_host_with_edr, hosts_with_edr, hosts_without_edr, linux_host_unhealthy_edr, mac_host_unhealthy_edr, windows_host_unhealthy_edr, hosts_with_unhealthy_edr, attempted_host_patching, successful_host_patching, failed_host_patching, raw) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: vrathi
--

COPY public.roles (id, name, description, permissions, created_at) FROM stdin;
0d4b6cb9-9e43-49ab-8b4a-5f81476b438a	ROLE_ADMIN	Administrator role with full access	USER_READ,  USER_WRITE, USER_DELETE, PROFILE_READ, PROFILE_WRITE, PROFILE_DELETE	2025-01-21 20:31:56.337563
bda45a0b-c6c6-448a-a712-6b6f4f2bd18c	ROLE_USER	Standard userEntity role	USER_READ,  USER_WRITE, USER_DELETE, PROFILE_READ, PROFILE_WRITE, PROFILE_DELETE	2025-01-21 20:31:56.337563
\.


--
-- Data for Name: task_logs; Type: TABLE DATA; Schema: public; Owner: vrathi
--

COPY public.task_logs (task_log_id, task_id, log_datetime, log_message, progress_percentage, log_date_time) FROM stdin;
\.


--
-- Data for Name: task_master; Type: TABLE DATA; Schema: public; Owner: vrathi
--

COPY public.task_master (task_id, task_name, task_type, task_subtype, task_tags, task_input, task_agent_id, task_status, task_logs, progress, task_sub_type, task_result, task_start_time, task_end_time) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: vrathi
--

COPY public.user_profiles (id, user_id, email, first_name, last_name, profile_picture_url, phone_number, bio, created_at, updated_at) FROM stdin;
be82c9ee-5f4d-4dfd-95d5-309d97f09cdf	bc7fe52d-7475-46cc-9aa4-47c83f9fe73c	vijay.rathi@gmail.com	vijay	rathi	abc	123	aa	2025-01-21 21:33:10.213955	2025-01-21 21:33:10.213955
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: vrathi
--

COPY public.user_roles (user_id, role_id) FROM stdin;
bc7fe52d-7475-46cc-9aa4-47c83f9fe73c	0d4b6cb9-9e43-49ab-8b4a-5f81476b438a
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: vrathi
--

COPY public.users (id, username, password, enabled, created_at, updated_at) FROM stdin;
bc7fe52d-7475-46cc-9aa4-47c83f9fe73c	vijay.rathi@gmail.com	$2a$10$7EkY3vXv4fp8v7THMbxcJei/W9pDgBu9fzqYPTjipZF.VYMXgmxcW	t	2025-01-21 21:31:57.065638	2025-01-24 16:55:07.177009
\.


--
-- Name: activity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vrathi
--

SELECT pg_catalog.setval('public.activity_log_id_seq', 1, false);


--
-- Name: agent_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vrathi
--

SELECT pg_catalog.setval('public.agent_master_id_seq', 2, true);


--
-- Name: host_metrics_snapshot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vrathi
--

SELECT pg_catalog.setval('public.host_metrics_snapshot_id_seq', 732, true);


--
-- Name: task_logs_task_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vrathi
--

SELECT pg_catalog.setval('public.task_logs_task_log_id_seq', 20, true);


--
-- Name: task_master_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vrathi
--

SELECT pg_catalog.setval('public.task_master_task_id_seq', 17, true);


--
-- Name: activity_log activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_pkey PRIMARY KEY (id);


--
-- Name: agent_master agent_master_agent_client_id_key; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.agent_master
    ADD CONSTRAINT agent_master_agent_client_id_key UNIQUE (agent_client_id);


--
-- Name: agent_master agent_master_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.agent_master
    ADD CONSTRAINT agent_master_pkey PRIMARY KEY (id);


--
-- Name: host_metrics_snapshot host_metrics_snapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.host_metrics_snapshot
    ADD CONSTRAINT host_metrics_snapshot_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: task_logs task_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_logs
    ADD CONSTRAINT task_logs_pkey PRIMARY KEY (task_log_id);


--
-- Name: task_master task_master_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_master
    ADD CONSTRAINT task_master_pkey PRIMARY KEY (task_id);


--
-- Name: user_profiles user_profiles_email_key; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_email_key UNIQUE (email);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_failed_patching; Type: INDEX; Schema: public; Owner: vrathi
--

CREATE INDEX idx_failed_patching ON public.host_metrics_snapshot USING btree (failed_host_patching);


--
-- Name: idx_timestamp; Type: INDEX; Schema: public; Owner: vrathi
--

CREATE INDEX idx_timestamp ON public.host_metrics_snapshot USING btree ("timestamp");


--
-- Name: idx_unhealthy_edr; Type: INDEX; Schema: public; Owner: vrathi
--

CREATE INDEX idx_unhealthy_edr ON public.host_metrics_snapshot USING btree (hosts_with_unhealthy_edr);


--
-- Name: task_logs task_logs_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_logs
    ADD CONSTRAINT task_logs_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.task_master(task_id);


--
-- Name: task_master task_master_task_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.task_master
    ADD CONSTRAINT task_master_task_agent_id_fkey FOREIGN KEY (task_agent_id) REFERENCES public.agent_master(id);


--
-- Name: user_profiles user_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vrathi
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

