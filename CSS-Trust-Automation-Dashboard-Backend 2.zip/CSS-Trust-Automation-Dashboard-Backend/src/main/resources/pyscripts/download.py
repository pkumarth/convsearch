import requests
import os
import sys 
import json


def download_installer(api_url, api_key, os_type, os_version, installer_name):
    """
    Download installer from API with presigned URL
    
    :param api_url: Base API URL
    :param api_key: API Key for authentication
    :param os_type: Operating system type
    :param os_version: Operating system version
    :param installer_name: Name to save the downloaded installer
    :return: Path to downloaded installer
    """
    # Construct query parameters
    params = {
        'os': os_type,
        'name': 'Crowdstrike Falcon',
        'osVersion': os_version
    }
    
    # Headers for API request
    headers = {
        'x-api-key': api_key
    }
    
    try:
        # Fetch presigned URL
        response = requests.get(api_url, params=params, headers=headers)
        response.raise_for_status()  # Raise an exception for bad responses
        
        # Debug: Print the response content
        print("API Response:", response.text)
        
        # Parse JSON response
        json_response = response.json()
        print("JSON Response Type:", type(json_response))
        print("JSON Response Content:", json.dumps(json_response, indent=2))
        
        # Handle list response
        if isinstance(json_response, list):
            if len(json_response) > 0:
                presigned_url = json_response[0].get('presignedURL')
            else:
                raise ValueError("Empty response list")
        else:
            presigned_url = json_response.get('presignedURL')
        
        if not presigned_url:
            raise ValueError("No presigned URL found in the response")
        
        print(f"Presigned URL found: {presigned_url}")
        
        # Download the file
        print("Downloading file...")
        file_response = requests.get(presigned_url)
        file_response.raise_for_status()
        
        # Ensure downloads directory exists
        os.makedirs('downloads', exist_ok=True)
        
        # Full path for saving the installer
        download_path = os.path.join('downloads', installer_name)
        
        # Save the file
        with open(download_path, 'wb') as f:
            f.write(file_response.content)
        
        print(f"Installer downloaded successfully to {download_path}")
        return download_path
    
    except requests.RequestException as e:
        print(f"Error downloading installer: {e}")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        return None


def main():
    # Configuration - replace with your actual values
    API_URL = "https://my3nol2dcd.execute-api.us-west-2.amazonaws.com/v1/aws/installer"
    API_KEY = sys.argv[1]
    OS_TYPE = "windows-client"
    OS_VERSION = "10"
    INSTALLER_NAME = "crowdstrike_falcon_installer.exe"
    
    # Download the installer
    download_path = download_installer(
        API_URL, 
        API_KEY, 
        OS_TYPE, 
        OS_VERSION, 
        INSTALLER_NAME
    )

if __name__ == "__main__":
    main()

