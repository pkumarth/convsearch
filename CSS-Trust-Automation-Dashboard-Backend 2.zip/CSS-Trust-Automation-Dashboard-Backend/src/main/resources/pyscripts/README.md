# Automation Suit

## Overview
This project consists of three main components:
- **Server Application** (Java 17, PostgreSQL)
- **Frontend Application** Angular
- **Agent Application** (Python)

---

## Server Application

### Prerequisites
- Java 17
- PostgreSQL

### Installation & Setup
1. **Import the database**
   - Load the provided SQL file into your PostgreSQL database.

2. **Set environment variables**
   Configure the following environment variables:
   ```sh
   export DB_HOST=localhost
   export DB_PORT=5432
   export DB_NAME=mydatabase
   export DB_USERNAME=myuser
   export DB_PASSWORD=mypassword
   ```

3. **Run the application**
   ```sh
   java -jar flyweb.jar
   ```

4. **Verify the application is running**
   - The server should start successfully if all configurations are correct.
   - By default, the application listens on **port 8080**.

---

## Frontend Application
<TODO: Add setup and installation instructions>

---

## Agent Application

### Prerequisites
- Python 3.x
- Virtual environment setup

### Installation & Setup
1. **Create a virtual environment**
   ```sh
   python -m venv venv
   ```

2. **Activate the virtual environment**
   - On Windows:
     ```sh
     venv\Scripts\activate
     ```
   - On macOS/Linux:
     ```sh
     source venv/bin/activate
     ```

3. **Install required packages**
   ```sh
   pip install -r requirements.txt
   ```

4. Update agnent.conf file with environment specific values


5. **Run the agent application**
  After activating the virtual environment, run the agent application:
   ```sh
   python agent.py agent.conf
   ```

---

## License
This project is licensed under the MIT License.

## Contact
For any questions or support, please contact [Your Contact Information].
