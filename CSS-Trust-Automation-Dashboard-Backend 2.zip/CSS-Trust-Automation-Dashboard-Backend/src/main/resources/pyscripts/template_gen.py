import json
import os
import sys
from datetime import datetime
import uuid
from edr_utils import get_win_edr_config,get_linux_edr_config

path_prefix = "/ansible/playbooks/"

def install_win_edr(*args):
    try:
        return get_win_edr_config(args[0])
    except ImportError:
        # Fallback values if import fails
        return {
        }


def default_handler(*args):
    # Default handler that takes any number of arguments and returns empty dict
    return {}



def install_linux_edr(*args):
    # Implement Linux EDR specific logic here  
    # Return dictionary with required key-value pairs

    print(f"LNX {args}")

    account_id = args[0]
    api_token=""
    client_id="Y6MTqRiMU9UxeRpTp8FJV1mev9"
    client_secret="958NIcA3CbWb6!zbg-3SVA5f96!sirzbxgE1tVILnGcCt5mQJnC4yNL1ymLvySb_"
    sentinel_token="rm28VBCQWhxqtvW0CNh8TO4Z2eRzD7iJKAheNlHTLEsxBMX40k3DwczItNDyb8lxP5X5tEDBT9CxFZdH"
    sentinel_api_key="14ogQ9j3GF3so0w47I6UB7noqNleUbwz9cUttDUN"
    return get_linux_edr_config(client_id,client_secret,sentinel_token,sentinel_api_key,account_id)

def create_json_file(template_path, inventory_path, task_type, output_filename, argdata):
    # Read template JSON file
    with open(template_path) as f:
        template_data = json.load(f)


    # Get task specific values based on task_type
    task_handlers = {
        "install_win_edr": install_win_edr,
        "install_linux_edr": install_linux_edr
    }
    
    # Use default_handler instead of lambda
    task_values = {}
    if task_type:
        handler = task_handlers.get(task_type, default_handler)
        task_values = handler(*sys.argv[5:])

    # Update inventory path
    template_data["inventory"] = f"{path_prefix}{inventory_path}"
    
    # Update extra_vars if task_values is not empty
    if task_values:
        extra_vars = " ".join([f"{k}={v}" for k,v in task_values.items()])
        extra_vars = f"target_hosts=all {extra_vars}"
        template_data["extra_vars"] = extra_vars
        
    # Generate dynamic filename with timestamp
    # timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    # unique_id = str(uuid.uuid4())
    # output_filename = f"task_{task_type}_{timestamp}_{unique_id}.json"
    
    # Write updated data to new JSON file
    with open(output_filename, 'w') as f:
        json.dump(template_data, f, indent=2)
        
    return output_filename

def main():
    if len(sys.argv) < 4:
        print("Usage: script.py <template_json_path> <inventory_path> <task_type>")
        sys.exit(1)
        
    template_path = sys.argv[1]
    inventory_path = sys.argv[2] 
    task_type = sys.argv[3]
    output_file = sys.argv[4]

    if not os.path.exists(template_path):
        print(f"Template file {template_path} does not exist")
        sys.exit(1)
    argdata=sys.argv[4:]
    output_file = create_json_file(template_path, inventory_path, task_type, output_file,argdata)
    print(f"{output_file}")

if __name__ == "__main__":
    main()

