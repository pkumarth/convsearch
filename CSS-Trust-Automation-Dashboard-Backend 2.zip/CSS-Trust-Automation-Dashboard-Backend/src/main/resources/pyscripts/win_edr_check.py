import json
import sys
import requests
from postprocess_utils import get_result_array

def find_host_by_id(hostmetadata_array, host_id):
    for host_obj in hostmetadata_array:
        if host_obj['hostId'] == host_id:
            metajs = host_obj.get('metadata',{})
            metadata = json.loads(metajs)
            inst_id = metadata.get('instanceId')
            return inst_id,host_obj.get('cstext',{})
    return 'not found'

def verify_edr_health(instance_id,client_id,client_secret ):
    d = {
            "client_id": client_id, 
            "client_secret" : client_secret 
        }

    getCredResponse = requests.post(url="https://api.crowdstrike.com/oauth2/token", data=d)
    getCredResponseJson = getCredResponse.json()
    access_token = getCredResponseJson['access_token']

    __headers = {
        "accept": "application/json",
        "authorization": f"bearer {access_token}"
    }
    __param = {
        'filter': f"instance_id:'{instance_id}'+(last_seen:>='now-1h'+last_seen:<'now')"
    }
    response = requests.get(url="https://api.crowdstrike.com/devices/queries/devices/v1", headers=__headers, params=__param)
    response1 = response.json()
    #print(f"response1 = {response1}")
    offset = response1['meta']['pagination']['offset']
    #print(f"offset = {offset}")

    if offset > 0:
        return True
    else:
        return False 

# Define the path to the JSON file
json_file_path = sys.argv[1]
task_res_file = sys.argv[2]

# Read the JSON file
with open(json_file_path, "r") as file:
    data = json.load(file)

# Access the 'postrun_script_args' list
postrun_script_args = data.get("postrun_script_args", []) 
# Iterate through 'postrun_script_args' and access keys
for index, args in enumerate(postrun_script_args):
    client_id = args.get("client_id", None)
    client_secret = args.get("client_secret", None)

# Read the JSON file
with open(task_res_file, "r") as file:
    result_json = json.load(file)

json_obj = get_result_array(result_json) 

hosts = result_json['output']
hostmetadata = []
for host in hosts:
    tasks = host['hostDetails']['tasks']

    hmdoc = {
                'hostId' : None,
                'metadata' : None,
                'cstext' : None
            }
    for task in tasks:
        if "Fetch instance identity document".lower() in task['task'].lower() and task['status'] ==  "runner_on_ok":
            metajson = task["result"]["stdout"]
            hmdoc['hostId'] = host['hostId']
            hmdoc['metadata'] = metajson
        
        if "Check if CrowdStrike agent is installed".lower() in task['task'].lower() and task['status'] ==  "runner_on_ok":
            cstext = task["result"]["stdout"]
            hmdoc['cstext'] = cstext 

    hostmetadata.append(hmdoc)

hosts = json_obj['taskstatus']

for host in hosts:
    code=host['code']

    inst_id, cstext = find_host_by_id(hostmetadata,host['hostname'])

#    print(f"CSSS ---> {inst_id} {code} {cstext}")

    if  code == 1200 and 'CrowdStrike'.lower() in cstext.lower() : 
        cstate = verify_edr_health(inst_id,client_id,client_secret)
        if cstate == False:
            host['code'] = 1502
            host['status'] = 'Reporting Failed'
        else:
            host['status'] = 'EDR Reporting Ok!'
    else:
        host['code'] = 1501
        host['status'] = 'May be installation not found'

json_obj['taskstatus']=hosts

print(f"{json_obj}")
 
 
