#!/bin/bash

# Check SentinelOne status
command=$(/opt/sentinelone/bin/sentinelctl management status)

# Extract connectivity and URL information
connectivity=$(echo "$command" | awk '/Connectivity/ {print $NF}')
url=$(echo "$command" | awk '/URL/ {print $NF}')

# Check if SentinelOne is connected to the expected URL
if [ "$connectivity" = "On" ] && [ "$url" = "https://autodesk.sentinelone.net" ]; then
  echo "Sentinelone"
else
  echo "NA"
fi
