import json
import sys
import requests
from postprocess_utils import get_result_array

def find_host_by_id(hostmetadata_array, host_id):
    for host_obj in hostmetadata_array:
        if host_obj['hostId'] == host_id:
            metajs = host_obj.get('metadata',{})
            metadata = json.loads(metajs)
            inst_id = metadata.get('instanceId')
            return inst_id
    return 'not found'

def verify_sentinel(instance_id,apiToken):
    url = "https://autodesk.sentinelone.net/web/api/v2.1/agents"
    params = {'cloudInstanceId__contains': f'{instance_id}'}
    headers = {'Authorization': f'ApiToken {apiToken}'}
    response = requests.get(url, params=params, headers=headers)
    response1 = response.json()
    #print(f"instance = {instance_id}")
    #print(f"response1 = {response1}")
    data = response1['data']
    return data 

# Define the path to the JSON file
json_file_path = sys.argv[1]
task_res_file = sys.argv[2]

# Read the JSON file
with open(json_file_path, "r") as file:
    data = json.load(file)

# Access the 'postrun_script_args' list
postrun_script_args = data.get("postrun_script_args", [])

# Iterate through 'postrun_script_args' and access keys
for index, args in enumerate(postrun_script_args):
    apiToken = args.get("SentionelOne_ApiToken", None)
    apiKey = args.get("SentionelOneX_APIKey", None)

# Read the JSON file
with open(task_res_file, "r") as file:
    result_json = json.load(file)

json_obj = get_result_array(result_json) 

hosts = result_json['output']
hostmetadata = []
for host in hosts:
    tasks = host['hostDetails']['tasks']
    for task in tasks:
        if "Fetch instance identity document".lower() in task['task'].lower() and task['status'] ==  "runner_on_ok":
            metajson = task["result"]["stdout"]
            hmdoc = {
                    'hostId' : host['hostId'],
                    'metadata' : metajson
                    }
            hostmetadata.append(hmdoc)


hosts = json_obj['taskstatus']

for host in hosts:
    code=host['code']
    stdout=host['stdout']
    if  code == 1200 and 'Sentinelone'.lower() in stdout.lower() :
        inst_id = find_host_by_id(hostmetadata,host['hostname'])
        data = verify_sentinel(inst_id,apiToken)
        if len(data) == 0:
            host['code'] = 1502
            host['status'] = 'Reporting Failed'
    else:
        host['code'] = 1501
        host['status'] = 'May be installation not found'

json_obj['taskstatus']=hosts

print(f"{json_obj}")
 
 
