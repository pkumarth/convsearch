#!/bin/bash

set -e  # Exit on error


while [[ $# -gt 0 ]]; do
    case $1 in
        --service_id)
            if [[ -n "$2" && ${2:0:1} != "-" ]]; then
                service_id="$2"
                shift 2
            else
                echo "Error: --service_id requires an argument"
                usage
            fi
            ;;
        --site_token)
            if [[ -n "$2" && ${2:0:1} != "-" ]]; then
                site_token="$2"
                shift 2
            else
                echo "Error: --site_token requires an argument"
                usage
            fi
            ;;
        --api_key)
            if [[ -n "$2" && ${2:0:1} != "-" ]]; then
                api_key="$2"
                shift 2
            else
                echo "Error: --api_key requires an argument"
                usage
            fi
            ;;
        -h|--help)
            usage
            ;;
        *)
            # Ignore unknown parameters by shifting past them
            shift
            ;;
    esac
done


#            [shell_script, api_key, service_id, site_token],
# Variables (Replace placeholders with actual values)
API_KEY="$api_key"
SERVICE_ID="$service_id"
SITE_TOKEN="$site_token"

# Retrieve AWS Instance ID
INSTANCE_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
if [ -z "$INSTANCE_ID" ]; then
    echo "Error: Unable to retrieve AWS instance ID. Ensure this script is running on an AWS instance."
    INSTANCE_ID="undef"
fi

# Function for SentinelOne post-install steps
configure_sentinelctl() {
    sudo /opt/sentinelone/bin/sentinelctl management customer_id set "$INSTANCE_ID"
    sudo /opt/sentinelone/bin/sentinelctl management token set "$SITE_TOKEN"
    sudo /opt/sentinelone/bin/sentinelctl control start
    sudo /opt/sentinelone/bin/sentinelctl management status
}

# Function for Ubuntu
install_on_ubuntu() {
    echo "Installing SentinelOne on Ubuntu..."
    sudo apt-get update
    sudo apt-get install -y jq
    arch=$(uname -m)
    if [ "$arch" = "x86_64" ]; then
        url=$(curl -H "x-api-key: $API_KEY" \
            "https://my3nol2dcd.execute-api.us-west-2.amazonaws.com/v1/aws/installer?os=ubuntu&name=Sentinel%20One&osVersion=20.04" \
            | jq -r ".[0].presignedURL")
    else
        url=$(curl -H "x-api-key: $API_KEY" \
            "https://my3nol2dcd.execute-api.us-west-2.amazonaws.com/v1/aws/installer?os=ubuntu&name=Sentinel%20One&osVersion=20.04&platform=arm64" \
            | jq -r ".[0].presignedURL")
    fi
    wget -O SentinelOne.deb "$url"
    sudo dpkg -i SentinelOne.deb
    configure_sentinelctl
}

# Function for Amazon Linux
install_on_amazon_linux() {
    echo "Installing SentinelOne on Amazon Linux..."
    sudo yum install -y jq
    arch=$(uname -m)
    if [ "$arch" = "x86_64" ]; then
        url=$(curl -H "x-api-key: $API_KEY" \
            "https://my3nol2dcd.execute-api.us-west-2.amazonaws.com/v1/aws/installer?os=amazon-linux&name=Sentinel%20One&osVersion=2" \
            | jq -r ".[0].presignedURL")
    else
        url=$(curl -H "x-api-key: $API_KEY" \
            "https://my3nol2dcd.execute-api.us-west-2.amazonaws.com/v1/aws/installer?os=amazon-linux&name=Sentinel%20One&osVersion=2&platform=aarch64" \
            | jq -r ".[0].presignedURL")
    fi
    wget -O SentinelOne.rpm "$url"
    sudo rpm -i --nodigest SentinelOne.rpm
    configure_sentinelctl
}

# Function for RHEL
install_on_rhel() {
    echo "Installing SentinelOne on RHEL..."
    sudo sed -i "s/Defaults    requiretty/#Defaults    requiretty/g" /etc/sudoers
    sudo yum install -y jq wget
    arch=$(uname -m)
    if [ "$arch" = "x86_64" ]; then
        url=$(curl -H "x-api-key: $API_KEY" \
            "https://my3nol2dcd.execute-api.us-west-2.amazonaws.com/v1/aws/installer?os=rhel&name=Sentinel%20One&osVersion=7.9" \
            | jq -r ".[0].presignedURL")
    else
        url=$(curl -H "x-api-key: $API_KEY" \
            "https://my3nol2dcd.execute-api.us-west-2.amazonaws.com/v1/aws/installer?os=rhel&name=Sentinel%20One&osVersion=8&platform=aarch64" \
            | jq -r ".[0].presignedURL")
    fi
    wget -O SentinelOne.rpm "$url"
    sudo rpm -i --nodigest SentinelOne.rpm
    configure_sentinelctl
}

# Main script
if [ -f /etc/os-release ]; then
    . /etc/os-release
    case "$ID" in
        ubuntu)
            install_on_ubuntu
            ;;
        amzn)
            install_on_amazon_linux
            ;;
        rhel)
            install_on_rhel
            ;;
        *)
            echo "Unsupported OS: $ID"
            exit 1
            ;;
    esac
else
    echo "Cannot determine OS."
    exit 1
fi

