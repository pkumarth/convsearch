import json
import sys
import requests
from postprocess_utils import get_result_array 

# Define the path to the JSON file
json_file_path = sys.argv[1]
task_res_file = sys.argv[2]

# Read the JSON file
with open(json_file_path, "r") as file:
    data = json.load(file)
# Access the 'postrun_script_args' list
postrun_script_args = data.get("postrun_script_args", [])

# Read the JSON file
with open(task_res_file, "r") as file:
    result_json = json.load(file)

json_obj = get_result_array(result_json)
print(f"{json_obj}")
