import json
import ansible_runner
import sys
import os
from typing import Dict, Any
from pathlib import Path

def resolve_path(path: str) -> str:
    """
    Convert relative path to absolute path based on the current working directory
    
    Args:
        path (str): Relative or absolute path
        
    Returns:
        str: Absolute path
    """
    if path.startswith('./'):
        return os.path.abspath(path)
    return path

def run_ansible_playbook(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Execute an Ansible playbook using the provided configuration.
    
    Args:
        config (dict): Configuration dictionary containing playbook details
        
    Returns:
        dict: Results of the playbook execution organized by host
    """
    # Convert relative paths to absolute paths
    playbook = resolve_path(config['playbook'])
    inventory = resolve_path(config['inventory'])
    
    # Verify files exist
    if not os.path.exists(playbook):
        raise FileNotFoundError(f"Playbook not found: {playbook}")
    if not os.path.exists(inventory):
        raise FileNotFoundError(f"Inventory file not found: {inventory}")
    
    # Print paths for debugging
    print(f"Using playbook: {playbook}")
    print(f"Using inventory: {inventory}")
    
    extra_vars = config['extra_vars']
    debug = config.get('debug', False)
    
    # Convert extra_vars string to dictionary
    if isinstance(extra_vars, str):
        extra_vars_dict = {}
        for item in extra_vars.split():
            if '=' in item:
                key, value = item.split('=')
                extra_vars_dict[key] = value
    else:
        extra_vars_dict = extra_vars
    
    # Get the private data directory (where ansible-runner will store its data)
    private_data_dir = os.path.join(os.getcwd(), '.ansible-runner')
    os.makedirs(private_data_dir, exist_ok=True)
    
    # Run the playbook
    runner = ansible_runner.run(
        private_data_dir=private_data_dir,
        playbook=playbook,
        inventory=inventory,
        extravars=extra_vars_dict,
        debug=debug
    )
    
    # Process results
    results = {
        'status': runner.status,
        'stats': runner.stats,
        'host_results': {}
    }
    
    # Organize results by host
    for event in runner.events:
        if event.get('event') == 'runner_on_ok' or event.get('event') == 'runner_on_failed':
            host = event.get('event_data', {}).get('host')
            task = event.get('event_data', {}).get('task')
            
            if host:
                if host not in results['host_results']:
                    results['host_results'][host] = []
                
                results['host_results'][host].append({
                    'task': task,
                    'status': 'success' if event['event'] == 'runner_on_ok' else 'failed',
                    'result': event.get('event_data', {}).get('res', {})
                })
    
    return results

def main():
    """
    Main function to read input configuration and execute the playbook
    """
    # Print current working directory for debugging
    print(f"Current working directory: {os.getcwd()}")
    
    try:
        if len(sys.argv) > 1:
            # Read from file if provided as argument
            config_path = resolve_path(sys.argv[1])
            print(f"Reading config from: {config_path}")
            with open(config_path, 'r') as f:
                config = json.load(f)
        else:
            # Use sample configuration
            current_directory = os.getcwd()
            config = {
                'playbook': f'/home/ubuntu/final/agent/playbooks/mac_updates.yml',
                'inventory': f'/home/ubuntu/final/agent/tasks/inventory_20250205_190211_1133ab2a-7d7b-4088-920f-e41d2616d0c7.ini',
                'extra_vars': 'target_hosts=all',
                'postrun_script': 'postprocess_default.py',
                'postrun_script_args': [{'none': 'none'}],
                'debug': True
            }
        print(f"conf -> {config}")
        #sys.exit(1)
        # Execute playbook
        results = run_ansible_playbook(config)
        
        # Print results
        print("\nPlaybook Execution Results:")
        print(f"Status: {results['status']}")
        print("\nStats:")
        print(json.dumps(results['stats'], indent=2))
        
        print("\nHost-wise Results:")
        for host, host_results in results['host_results'].items():
            print(f"\nHost: {host}")
            for task_result in host_results:
                print(f"\nTask: {task_result['task']}")
                print(f"Status: {task_result['status']}")
                print("Result:")
                print(json.dumps(task_result['result'], indent=2))
        
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
