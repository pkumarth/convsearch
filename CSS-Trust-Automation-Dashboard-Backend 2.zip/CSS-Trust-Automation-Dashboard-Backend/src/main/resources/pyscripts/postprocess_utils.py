import json
import sys
import requests

def get_result_array(data_task_res):
    hosts = data_task_res["output"]
    scrout = []
    for host in hosts:
        hostname = host["hostId"]
        finalout = host["hostDetails"]["finalout"]

        proc_rc = host["hostDetails"]["return_code"] #finalout.get("return_code", "") 
        
        if isinstance(finalout, dict):
            stdout_value = finalout.get("stdout", "")
        else:
        # Handle the case where finalout is a string
            stdout_value = finalout


        # Accessing instanceId from instace_meta
        #instance_id = data_task_res["instace_meta"]["instanceId"]


        output_code = 1200
        output_status = "Successfuly Done!"

        if proc_rc != 0:
            output_code = 1501
            output_status = "Task Failed"

        hout={
                'hostname':hostname,
                'code':output_code,
                'stdout':stdout_value,
                'status':output_status
                }
        scrout.append(hout)

    final_out = { 
        'taskstatus' : scrout,
        'data_task_res':hosts  
        }
    return final_out



