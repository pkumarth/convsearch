package com.kimaya.flyweb.tasktracker.repo;

import com.kimaya.flyweb.tasktracker.entities.AgentEntity;
import com.kimaya.flyweb.tasktracker.entities.TaskEntity;
import com.kimaya.flyweb.tasktracker.models.TaskFilterRequest;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<TaskEntity, Long>,  JpaSpecificationExecutor<TaskEntity>{

    List<TaskEntity> findByTaskStatus(String taskStatus);

    List<TaskEntity> findByAgent(AgentEntity agent);

    List<TaskEntity> findByTaskNameContaining(String taskName);

    List<TaskEntity> findByAgent_IdAndTaskStatus(Long agentId, String taskStatus);

    TaskEntity findByAgent_IdAndTaskId(Long agentId, Long taskId);

    @Modifying
    @Query("UPDATE TaskEntity t SET t.taskStatus = :newStatus,  t.taskLogs = :taskLogs, t.taskResult = :taskResult, t.taskEndTime = :taskEndTime WHERE t.agent.id = :agentId AND t.taskId = :taskId")
    void markTaskCompleted(Long agentId, Long taskId, String newStatus, String taskLogs, String taskResult, LocalDateTime taskEndTime);


    @Modifying
    @Query("UPDATE TaskEntity t SET t.taskStatus = :newStatus,  t.taskStartTime = :taskStartTime WHERE t.agent.id = :agentId AND t.taskId = :taskId")
    void markTaskStarted(Long agentId, Long taskId, String newStatus, LocalDateTime taskStartTime);


    static Specification<TaskEntity> withDynamicQuery(TaskFilterRequest filter) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (filter.getTaskName() != null) {
                predicates.add(criteriaBuilder.like(root.get("taskName"), "%" + filter.getTaskName() + "%"));
            }

            if (filter.getTaskType() != null) {
                predicates.add(criteriaBuilder.equal(root.get("taskType"), filter.getTaskType()));
            }

            if (filter.getTaskStatus() != null) {
                predicates.add(criteriaBuilder.equal(root.get("taskStatus"), filter.getTaskStatus()));
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }

    Long agent(AgentEntity agent);
}
