package com.kimaya.flyweb.usermgmt.controller.models;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ApiResponse extends FlyWebCommonRestResponse {
}