package com.kimaya.flyweb.tasktracker.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kimaya.flyweb.tasktracker.common.TaskStatus;
import com.kimaya.flyweb.tasktracker.dto.AgentDto;
import com.kimaya.flyweb.tasktracker.dto.TaskDto;
import com.kimaya.flyweb.tasktracker.models.TaskAddLogRequest;
import com.kimaya.flyweb.tasktracker.models.TaskStatusUpdateRequest;
import com.kimaya.flyweb.tasktracker.usecases.AgentUseCase;
import com.kimaya.flyweb.tasktracker.usecases.TaskCoreUseCase;
import com.kimaya.flyweb.usermgmt.controller.models.FlyWebCommonRestResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/tasks")
public class TaskTrackerCoreController {
    @Autowired
    AgentUseCase agentUseCase;

    @Autowired
    CommonRestUtils commonRestUtils;

    @Autowired
    TaskCoreUseCase taskCoreUseCase;

    @GetMapping("/getTasks")
    public ResponseEntity<FlyWebCommonRestResponse> getTasks(@RequestHeader HttpHeaders headers) {
        AgentDto agentDto = commonRestUtils.getAgent(headers);
        if (agentDto == null) {
            FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(false, 500, "Invalid Credentials", "Invalid Credentials");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        List<TaskDto> tasks = taskCoreUseCase.getTasks(agentDto);
        FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
        response.setResult(CommonRestUtils.listToMap(Collections.singletonList(tasks), "tasks"));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    //def post_task_event(task_id, task_status, task_logs, progressPercentage):
    @PostMapping("/updateStatus")
    public ResponseEntity<FlyWebCommonRestResponse> updateTask(@RequestBody TaskStatusUpdateRequest request, @RequestHeader HttpHeaders headers) {
        AgentDto agentDto = commonRestUtils.getAgent(headers);
        if (agentDto == null) {
            FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(false, 500, "Invalid Credentials", "Invalid Credentials");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        taskCoreUseCase.processStatusUpdate(request, agentDto.getId());

        FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @PostMapping("/completed")
    public ResponseEntity<FlyWebCommonRestResponse> taskCompleted(@RequestBody Map<String, Object> inpReq, /*@RequestBody TaskStatusUpdateRequest request,*/ @RequestHeader HttpHeaders headers) throws JsonProcessingException {


        TaskStatusUpdateRequest request = new TaskStatusUpdateRequest();
        request.setTaskId(inpReq.get("taskId").toString());
        request.setResult((Map<String, Object>) inpReq.get("result"));
        request.setStatus(inpReq.get("status").toString());
        request.setLogMessage(inpReq.get("logMessage").toString());

        AgentDto agentDto = commonRestUtils.getAgent(headers);
        if (agentDto == null) {
            FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(false, 500, "Invalid Credentials", "Invalid Credentials");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        Long taskId = Long.parseLong(request.getTaskId());
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(request.getResult());
        taskCoreUseCase.taskCompleted(agentDto.getId(), taskId, TaskStatus.valueOf(request.getStatus()), request.getLogMessage(), jsonString);// request.getLogMessage(), request.getResult());
        FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @PostMapping("/addTaskLog")
    public ResponseEntity<FlyWebCommonRestResponse> addTaskLog(@RequestBody TaskAddLogRequest request, @RequestHeader HttpHeaders headers) {
        AgentDto agentDto = commonRestUtils.getAgent(headers);
        Long taskId = Long.parseLong(request.getTaskId());

        boolean failed = false;

        if (agentDto == null) {
            failed = true;
        } else {
            try {
                taskCoreUseCase.addTaskLog(agentDto.getId(), taskId, request.getMessage(), request.getProgressPercent(), LocalDateTime.now());
                FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
                return new ResponseEntity<>(response, HttpStatus.OK);
            }catch (Exception e) {
                failed = true;
            }
        }
        FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(false, 500, "Invalid Credentials", "Invalid Credentials");

        return new ResponseEntity<>(response, HttpStatus.OK);
    }


}
