package com.kimaya.flyweb.usermgmt.repo;


import com.kimaya.flyweb.usermgmt.entities.UserEntity;
import com.kimaya.flyweb.usermgmt.entities.UserProfileEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.UUID;



@Repository
public interface UserProfileRepository extends JpaRepository<UserProfileEntity, UUID> {
    // Existing methods
    Optional<UserProfileEntity> findByUserId(UUID userId);
    Optional<UserProfileEntity> findByUser(UserEntity user);

    // Find by email (unique constraint)
    Optional<UserProfileEntity> findByEmail(String email);

    // Find by first name or last name
    List<UserProfileEntity> findByFirstNameContainingIgnoreCase(String firstName);
    List<UserProfileEntity> findByLastNameContainingIgnoreCase(String lastName);

    // Combined first and last name search
    List<UserProfileEntity> findByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCase(
            String firstName, String lastName
    );

    // Find by phone number
    Optional<UserProfileEntity> findByPhoneNumber(String phoneNumber);

    // Find profiles created within a date range
    List<UserProfileEntity> findByCreatedAtBetween(Timestamp startDate, Timestamp endDate);

    // Custom query to find profiles with non-null profile pictures
    List<UserProfileEntity> findByProfilePictureUrlIsNotNull();

    // Count profiles by various criteria
    long countByFirstNameIgnoreCase(String firstName);
    long countByLastNameIgnoreCase(String lastName);

    // Delete by email or user
    void deleteByEmail(String email);
    void deleteByUser(UserEntity user);

    @Query("SELECT up FROM UserProfileEntity up WHERE up.user = :userId")
    Optional<UserProfileEntity> findProfileByUserId(@Param("userId") UUID userId);

    // Custom query with multiple conditions
    @Query("SELECT up FROM UserProfileEntity up WHERE " +
            "(up.firstName LIKE %:searchTerm% OR up.lastName LIKE %:searchTerm%) " +
            "AND up.profilePictureUrl IS NOT NULL")
    List<UserProfileEntity> findProfilesWithPictureByName(@Param("searchTerm") String searchTerm);
}