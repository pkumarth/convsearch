package com.kimaya.flyweb.analytics.mapper;

import com.kimaya.flyweb.analytics.dto.DashQueryMapDto;
import com.kimaya.flyweb.analytics.entity.DashQueryMapEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface DashQueryMapper {
    DashQueryMapDto toDto(DashQueryMapEntity dashQueryMapEntity);
    DashQueryMapEntity toEntity(DashQueryMapDto dashQueryMapDto);
}