package com.kimaya.flyweb.usermgmt.controller;

import com.kimaya.flyweb.usermgmt.controller.models.ChangePasswordRequest;
import com.kimaya.flyweb.usermgmt.controller.models.FlyWebCommonRestResponse;
import com.kimaya.flyweb.usermgmt.controller.models.JwtAuthResponse;
import com.kimaya.flyweb.usermgmt.controller.models.LoginRequest;
import com.kimaya.flyweb.usermgmt.usecases.UserDataService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {
    @Autowired
    private UserDataService userDataService;


    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) throws Exception {
        String jwt = userDataService.authenticate(loginRequest.getUsername(), loginRequest.getPassword(), SecurityContextHolder.getContext());

        // Return both token and user information
        return ResponseEntity.ok(new JwtAuthResponse(jwt, ""));
    }

    @PutMapping("/password")
    public ResponseEntity<?> changePassword(@Valid @RequestBody ChangePasswordRequest request) throws Exception {
        Boolean result = userDataService.changePassword(request, SecurityContextHolder.getContext());
        FlyWebCommonRestResponse response = new FlyWebCommonRestResponse();
        if(result) {
            response.setSuccess(true);
            response.setCode(200);
            response.setMessage("Password changed");
            response.setCause("Successfully Done!");
        }else{
            response.setSuccess(false);
            response.setCode(500);
            response.setMessage("Change Password Failed");
            response.setCause("Change Password Failed");
        }
        return ResponseEntity.ok(response);
    }

/*
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRequest signUpRequest) {
        if (userDataService.existsByUsername(signUpRequest.getUsername())) {
            return ResponseEntity.badRequest()
                    .body(new ApiResponse(false, "Username already taken!"));
        }

        userDataService.createUser(signUpRequest);
        return ResponseEntity.ok(new ApiResponse(true, "User registered successfully"));
    }*/
}