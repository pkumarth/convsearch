package com.kimaya.flyweb.tasktracker.models;

import lombok.Data;

@Data
public class TaskResultUpdateRequest {
}
