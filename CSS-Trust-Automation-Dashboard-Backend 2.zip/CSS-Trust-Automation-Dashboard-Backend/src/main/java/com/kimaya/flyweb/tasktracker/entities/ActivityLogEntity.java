package com.kimaya.flyweb.tasktracker.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@RequiredArgsConstructor
@Data
@Entity
@Table(name = "Activity_Log")
public class ActivityLogEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long actorId;
    private String actorType;

    @Column(nullable = false)
    private LocalDateTime dateTime;

    @Column(nullable = false)
    private String action;
    private String actionDetails;
}
