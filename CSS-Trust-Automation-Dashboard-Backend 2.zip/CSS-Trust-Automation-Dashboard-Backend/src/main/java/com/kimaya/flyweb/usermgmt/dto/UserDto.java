package com.kimaya.flyweb.usermgmt.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {

    private UUID id;
    private String username;
    private String password;
    private boolean enabled;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private UserProfileDto userProfile;
    private Set<RoleDto> roleEntities;

}
/*
    private UUID id;
    private String username;
    private String password;
    private boolean enabled;
    private Set<String> roles;
    private UserProfileDto profile;

    private UUID id;
    private String username;
    private boolean enabled;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private UserProfileDTO userProfile;
    private Set<RoleDTO> roles;
 */