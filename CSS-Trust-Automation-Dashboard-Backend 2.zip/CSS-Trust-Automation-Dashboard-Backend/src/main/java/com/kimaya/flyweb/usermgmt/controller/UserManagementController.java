package com.kimaya.flyweb.usermgmt.controller;


import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
@PreAuthorize("hasRole('ADMIN')")
public class UserManagementController {
    /* @Autowired
    private UserDataService userDataService;

    @GetMapping
    public Page<UserDto> getAllUsers(Pageable pageable) {
        return userDataService.getAllUsers(pageable);
    }

    @GetMapping("/{id}")
    public UserDto getUser(@PathVariable UUID id) {
        return userDataService.getUserById(id);
    }


    @PutMapping("/{id}/roles")
    public ResponseEntity<?> updateUserRoles(@PathVariable UUID id, @RequestBody Set<String> roleNames) {
        userDataService.updateUserRoles(id, roleNames);
        return ResponseEntity.ok(new ApiResponse(true, "User roles updated successfully"));
    }*/
}