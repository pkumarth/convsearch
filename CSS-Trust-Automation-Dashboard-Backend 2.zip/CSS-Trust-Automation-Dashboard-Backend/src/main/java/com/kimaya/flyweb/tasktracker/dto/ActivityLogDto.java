package com.kimaya.flyweb.tasktracker.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@RequiredArgsConstructor
@Data
public class ActivityLogDto {

    private Long id;
    private Long actorId;
    private String actorType;
    private LocalDateTime dateTime;
    private String action;
    private String actionDetails;
}
