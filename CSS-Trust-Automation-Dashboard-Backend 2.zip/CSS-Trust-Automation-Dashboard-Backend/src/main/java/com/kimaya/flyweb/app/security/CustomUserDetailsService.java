package com.kimaya.flyweb.app.security;

import com.kimaya.flyweb.usermgmt.dto.RoleDto;
import com.kimaya.flyweb.usermgmt.dto.UserDto;
import com.kimaya.flyweb.usermgmt.usecases.RoleService;
import com.kimaya.flyweb.usermgmt.usecases.UserDataService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {
    private final  UserDataService userDataService;
    private final RoleService roleService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserDto userDto = userDataService.findByUsername(username);
        if (userDto == null) {
            throw new UsernameNotFoundException(username);
        }
        return new User(userDto.getUsername(), userDto.getPassword(), getAuthorities(userDto.getRoleEntities()));
    }

    private Collection<? extends GrantedAuthority> getAuthorities(
            Set<RoleDto> userRoles) {
        List<GrantedAuthority> authorities = new ArrayList<>();
        Set<String> perms = new HashSet<>();

        for (RoleDto role: userRoles) {
            perms.addAll(Set.of(role.getPermissions().split(",")));
        }
        for (String perm: perms) {
            authorities.add(new SimpleGrantedAuthority(perm));
        }

        return authorities;
    }


}
