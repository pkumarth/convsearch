package com.kimaya.flyweb.hostmetrics.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Date;

@Data
@RequiredArgsConstructor
public class HostMetricsSnapshotDto {
    private Date timestamp;
    private Integer totalHosts;
    private Integer totalLinuxHosts;
    private Integer totalMacHosts;
    private Integer totalWindowsHosts;
    private Integer linuxHostWithoutEdr;
    private Integer linuxHostWithEdr;
    private Integer macHostWithoutEdr;
    private Integer macHostWithEdr;
    private Integer windowsHostWithoutEdr;
    private Integer windowsHostWithEdr;
    private Integer hostsWithEdr;
    private Integer hostsWithoutEdr;
    private Integer linuxHostUnhealthyEdr;
    private Integer macHostUnhealthyEdr;
    private Integer windowsHostUnhealthyEdr;
    private Integer hostsWithUnhealthyEdr;
    private Integer attemptedHostPatching;
    private Integer successfulHostPatching;
    private Integer failedHostPatching;
    private String raw;
}
