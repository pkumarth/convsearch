package com.kimaya.flyweb.usermgmt.usecases;

import com.kimaya.flyweb.usermgmt.dto.UserDto;
import com.kimaya.flyweb.usermgmt.dto.UserProfileDto;
import com.kimaya.flyweb.usermgmt.entities.UserProfileEntity;
import com.kimaya.flyweb.usermgmt.repo.UserProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional
public class UserProfileService {
    @Autowired
    private UserProfileRepository userProfileRepository;

    public UserProfileDto convertToProfileDto(UserProfileEntity profile) {
        return UserProfileDto.builder()
                .firstName(profile.getFirstName())
                .lastName(profile.getLastName())
                .phoneNumber(profile.getPhoneNumber())
                .bio(profile.getBio())
                .profilePictureUrl(profile.getProfilePictureUrl())
                .build();
    }
    public UserProfileDto findByUser(UserDto userDto) {
        Optional<UserProfileEntity> entity = userProfileRepository.findProfileByUserId(userDto.getId());
        return convertToProfileDto(entity.get());
    }
}