package com.kimaya.flyweb.tasktracker.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@RequiredArgsConstructor
@Data
@Entity
@Table(name = "Task_Logs")
public class TaskLogEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long taskLogId;

    @ManyToOne
    @JoinColumn(name = "Task_Id")
    private TaskEntity task;

    @Column(nullable = false)
    private LocalDateTime logDateTime;

    @Column(nullable = false, name = "log_message", columnDefinition = "TEXT")
    private String logMessage;

    private Integer progressPercentage;
}
