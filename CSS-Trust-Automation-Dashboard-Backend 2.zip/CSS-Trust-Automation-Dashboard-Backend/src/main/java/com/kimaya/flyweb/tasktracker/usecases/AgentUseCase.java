package com.kimaya.flyweb.tasktracker.usecases;

import com.kimaya.flyweb.tasktracker.dto.AgentDto;
import com.kimaya.flyweb.tasktracker.entities.AgentEntity;
import com.kimaya.flyweb.tasktracker.mapper.AgentMapper;
import com.kimaya.flyweb.tasktracker.repo.AgentRepository;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@Transactional
@Lazy
public class AgentUseCase {
    @Autowired
    private AgentRepository agentRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    AgentMapper agentMapper;

    public AgentDto verifyAgent(String agentId, String agentSecret) {
        AgentEntity agentEntity = agentRepository.findByAgentClientId(agentId);
//        AgentMapper ab = AgentMapper.INSTANCE;

        if(agentEntity!=null && passwordEncoder.matches(agentSecret, agentEntity.getAgentSecret())) {
            return agentMapper.toAgentDto( agentEntity);
        }

        return null;
    }
    public AgentDto findAgent(String agentId) {
        AgentEntity agentEntity = agentRepository.findByAgentClientId(agentId);
        AgentDto agentDto = agentMapper.toAgentDto(agentEntity);
        return agentDto;
    }

    public boolean updateAgentLastLogTime(AgentDto agent, LocalDateTime lastLogTime) {

        if(agent==null)
            return false;

        agentRepository.updateAgentLastLogTime(agent.getAgentClientId(),lastLogTime);
        return true;
    }


    public AgentDto findAgentById(@NotNull(message = "Agent Id is required") Long agentId) {
        AgentEntity agentEntity = agentRepository.findById(agentId).get();
        AgentDto agentDto = agentMapper.toAgentDto(agentEntity);
        return agentDto;
    }
}
