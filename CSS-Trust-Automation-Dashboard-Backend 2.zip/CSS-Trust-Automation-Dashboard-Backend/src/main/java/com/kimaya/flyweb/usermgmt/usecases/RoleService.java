package com.kimaya.flyweb.usermgmt.usecases;

import com.kimaya.flyweb.usermgmt.dto.RoleDto;
import com.kimaya.flyweb.usermgmt.entities.RoleEntity;
import com.kimaya.flyweb.usermgmt.mapper.RoleMapper;
import com.kimaya.flyweb.usermgmt.repo.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional
public class RoleService {
    @Autowired
    private   RoleRepository roleRepository;
    @Autowired
    private   RoleMapper roleMapper;

    public List<RoleDto> findAll() {
        return roleRepository.findAll().stream()
                .map(roleMapper::toDto)
                .toList();
    }

    public Optional<RoleDto> findById(UUID id) {
        return roleRepository.findById(id)
                .map(roleMapper::toDto);
    }

    public RoleDto save(RoleDto roleDto) {
        RoleEntity role = roleMapper.toEntity(roleDto);
        RoleEntity savedRole = roleRepository.save(role);
        return roleMapper.toDto(savedRole);
    }

    public void deleteById(UUID id) {
        roleRepository.deleteById(id);
    }

    public boolean existsById(UUID id) {
        return roleRepository.existsById(id);
    }

    public Optional<RoleEntity> findByName(String name) {
        return Optional.ofNullable(roleRepository.findByName(name));
    }

    public RoleDto convertToDto(RoleEntity roleEntity) {
        RoleDto roleDto =  roleMapper.toDto(roleEntity);
        return roleDto;
    }
}
