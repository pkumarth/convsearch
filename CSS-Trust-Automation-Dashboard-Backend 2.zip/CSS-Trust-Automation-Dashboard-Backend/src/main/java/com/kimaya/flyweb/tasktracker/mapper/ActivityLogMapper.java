package com.kimaya.flyweb.tasktracker.mapper;


import com.kimaya.flyweb.tasktracker.dto.ActivityLogDto;
import com.kimaya.flyweb.tasktracker.entities.ActivityLogEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface ActivityLogMapper {

    ActivityLogMapper INSTANCE = Mappers.getMapper(ActivityLogMapper.class);

    ActivityLogEntity toActivityLogEntity(ActivityLogDto activityLogDto);

    ActivityLogDto toActivityLogDto(ActivityLogEntity activityLogEntity);
}