package com.kimaya.flyweb.tasktracker.controller;

import com.kimaya.flyweb.tasktracker.dto.AgentDto;
import com.kimaya.flyweb.tasktracker.usecases.AgentUseCase;
import com.kimaya.flyweb.usermgmt.controller.models.FlyWebCommonRestResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/agentcore/")
public class AgentController {
    @Autowired
    AgentUseCase agentUseCase;

    @Autowired
    CommonRestUtils commonRestUtils;

    @GetMapping("/heartbeat")
    public ResponseEntity<FlyWebCommonRestResponse> updateAgent(@RequestHeader HttpHeaders headers){

        AgentDto agentDto = commonRestUtils.getAgent(headers);

        if(agentDto!=null){
            agentUseCase.updateAgentLastLogTime(agentDto , LocalDateTime.now());
            FlyWebCommonRestResponse response = new FlyWebCommonRestResponse();
            response.setSuccess(true);
            response.setMessage("Successfully updated the agent");
            response.setCode(200);
            response.setCause("Successfully updated the agent");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }

        FlyWebCommonRestResponse response = new FlyWebCommonRestResponse();
        response.setSuccess(false);
        response.setMessage("Update Failed");
        response.setCode(500);
        response.setCause("Update Failed");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /*
    @PostMapping("/myEndpoint")
    public ResponseEntity<String> myEndpoint(@RequestHeader HttpHeaders headers, @RequestBody TaskResultUpdateRequest request) {
        String clientId = headers.getFirst("client-id");
        String clientSecret = headers.getFirst("client-secret");

        // Access the request body
        String dataFromBody = request.getData();

        // Use clientId, clientSecret, and dataFromBody for your logic
        // ...

        return ResponseEntity.status(HttpStatus.OK).body("Request received with client-id: " + clientId +
                ", client-secret: " + clientSecret + " and data: " + dataFromBody);
    }*/


}
