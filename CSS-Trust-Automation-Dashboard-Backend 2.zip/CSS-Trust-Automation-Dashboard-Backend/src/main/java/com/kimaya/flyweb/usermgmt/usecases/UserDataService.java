package com.kimaya.flyweb.usermgmt.usecases;

import com.kimaya.flyweb.app.security.utils.SecurityUtils;
import com.kimaya.flyweb.common.controller.ResourceNotFoundException;
import com.kimaya.flyweb.usermgmt.controller.models.ChangePasswordRequest;
import com.kimaya.flyweb.usermgmt.controller.models.SignUpRequest;
import com.kimaya.flyweb.usermgmt.dto.RoleDto;
import com.kimaya.flyweb.usermgmt.dto.UserDto;
import com.kimaya.flyweb.usermgmt.entities.RoleEntity;
import com.kimaya.flyweb.usermgmt.entities.UserEntity;
import com.kimaya.flyweb.usermgmt.entities.UserProfileEntity;
import com.kimaya.flyweb.usermgmt.mapper.UserMapper;
import com.kimaya.flyweb.usermgmt.repo.UserRepository;
import jakarta.annotation.PostConstruct;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
@Lazy
public class UserDataService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    @Lazy
    private RoleService roleService;

    @Autowired
    @Lazy
    private UserProfileService userProfileService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserMapper userMapper;


    @Autowired
    private AuthenticationProvider authenticationProvider;

    @Autowired
    private Environment environment;

    private String jwtSecurityKey;
    private String issuer;

    @PostConstruct
    public void init() {
        this.jwtSecurityKey = environment.getRequiredProperty("app.security.jwtSecurityKey");
        this.issuer = environment.getRequiredProperty("app.security.issuer");
    }

    public String authenticate(@NotBlank String username, @NotBlank String password, SecurityContext context) throws Exception{
        Authentication authentication = UsernamePasswordAuthenticationToken.unauthenticated(username, password);
        authentication = authenticationProvider.authenticate(authentication);
        context.setAuthentication(authentication);
        return SecurityUtils.createJwt(jwtSecurityKey,issuer,authentication);
    }

    public UserEntity createUser(SignUpRequest request) {
        UserEntity userEntity = new UserEntity();
        userEntity.setUsername(request.getUsername());
        userEntity.setPassword(passwordEncoder.encode(request.getPassword()));

        // Assign default role
        RoleEntity userRoleEntity = roleService.findByName("ROLE_USER")
                .orElseThrow(() -> new ResourceNotFoundException("Default role not found"));
        userEntity.getRoleEntities().add(userRoleEntity);

        // Create user profile
        UserProfileEntity profile = new UserProfileEntity();
        profile.setUser(userEntity);
        profile.setFirstName(request.getFirstName());
        profile.setLastName(request.getLastName());
        userEntity.setUserProfile(profile);

        UserEntity user =  userRepository.save(userEntity);
        return user;
    }

    public Page<UserDto> getAllUsers(Pageable pageable) {
        return userRepository.findAll(pageable)
                .map(this::convertToDto);
    }

    public UserDto getUserById(UUID id) {
        return userRepository.findById(id)
                .map(this::convertToDto)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }

    public void updateUserRoles(UUID userId, Set<String> roleNames) {
        UserEntity userEntity = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Set<RoleEntity> roleEntities = roleNames.stream()
                .map(name -> roleService.findByName(name)
                        .orElseThrow(() -> new ResourceNotFoundException("Role not found: " + name)))
                .collect(Collectors.toSet());

        userEntity.setRoleEntities(roleEntities);
        userRepository.save(userEntity);
    }

    private UserDto convertToDto(UserEntity userEntity) {
        Set<RoleDto> roles = userEntity.getRoleEntities().stream().map(roleEntity-> roleService.convertToDto(roleEntity)).collect(Collectors.toSet());


        return UserDto.builder()
                .id(userEntity.getId())
                .username(userEntity.getUsername())
                .password(userEntity.getPassword())
                .enabled(userEntity.isEnabled())
                .roleEntities(roles )
                .userProfile(userProfileService.convertToProfileDto(userEntity.getUserProfile()))
                .build();

    }



    public boolean existsByUsername(@NotBlank @Size(min = 3, max = 50) String username) {
        return userRepository.existsByUsername(username);
    }

    public UserDto findByUsername(String username) {
        Optional<UserEntity> userEntity = userRepository.findByUsername(username);
        return userEntity.map(this::convertToDto).orElse(null);
    
    }

    public Boolean changePassword(@Valid ChangePasswordRequest request, SecurityContext context)   {

        Authentication authentication = context.getAuthentication();
        String username = authentication.getName();

        UserEntity user = userRepository.findByUsername(username).get();
        if(user == null)
            return false;
        String pwd = user.getPassword();


        String currPass = request.getCurrentPassword();
        String dbPassword = user.getPassword();

        if(!passwordEncoder.matches(currPass, pwd))
            return false;

        String newpass = passwordEncoder.encode(request.getNewPassword());

        // Encode the new password
        user.setPassword(newpass);

        // Update the updated_at timestamp
        user.setUpdatedAt(LocalDateTime.now());

        userRepository.save(user);
        return true;

    }

    public UserDto findUserByUsername(@NotBlank String username) {
        Optional<UserEntity> user = userRepository.findByUsername(username);
        UserDto userDto = userMapper.toDTO(user.get());
        return userDto;
    }
}