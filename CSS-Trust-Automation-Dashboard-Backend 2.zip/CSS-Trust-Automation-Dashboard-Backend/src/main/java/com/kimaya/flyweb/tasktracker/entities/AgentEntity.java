package com.kimaya.flyweb.tasktracker.entities;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@RequiredArgsConstructor
@Data
@Entity
@Table(name = "Agent_Master")
public class AgentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String agentName;

    @Column(unique = true, nullable = false)
    private String agentClientId;

    @Column(nullable = false)
    private String agentSecret;

    @Column(nullable = false)
    private String agentStatus;

    @Column(nullable = false)
    private LocalDateTime agentLastReportedTime;
}
