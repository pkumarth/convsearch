package com.kimaya.flyweb.app.security.filters;


import com.kimaya.flyweb.app.security.constants.SecurityConstants;
import com.kimaya.flyweb.app.security.utils.SecurityUtils;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Set;


public class JWTTokenGeneratorFilter extends OncePerRequestFilter {

    private String jwtSecurityKey;
    private Set<String> openEndPointsSet;
    private String issuer;

    public JWTTokenGeneratorFilter(String jwtSecurityKey, Set<String> openEndPointsSet, String issuer) {
        this.jwtSecurityKey = jwtSecurityKey;
        this.openEndPointsSet = openEndPointsSet;
        this.issuer = issuer;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (null != authentication) {
            String jwt = null;
            try {
                jwt = SecurityUtils.createJwt(jwtSecurityKey,issuer,authentication);
                response.setHeader(SecurityConstants.JWT_HEADER, jwt);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        filterChain.doFilter(request, response);
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {

        String servletPath = request.getServletPath();
        return !openEndPointsSet.contains(servletPath.toLowerCase());

//        String[] endpoints = openEndPoints.split(",");
//        return !request.getServletPath().equals("/user");
    }

}
