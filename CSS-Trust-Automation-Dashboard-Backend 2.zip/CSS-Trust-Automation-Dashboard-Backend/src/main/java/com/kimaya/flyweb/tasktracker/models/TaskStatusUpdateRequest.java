package com.kimaya.flyweb.tasktracker.models;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class TaskStatusUpdateRequest {
    private String taskId;
    private String status;
    private String logMessage;
    private Map<String,Object> result;
    private Integer progressPercentage;

    Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
}
