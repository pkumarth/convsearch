package com.kimaya.flyweb.usermgmt.dto;

import lombok.*;

import java.util.UUID;
 

@Getter
@Setter
public class RoleDto {
   
    private UUID id;
    private String name;
    private String description;
    private String permissions;

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPermissions(String permissions) {
        this.permissions = permissions;
    }

    public String getPermissions() {
        return permissions;
    }
}
