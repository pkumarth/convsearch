package com.kimaya.flyweb.usermgmt.mapper;

import com.kimaya.flyweb.usermgmt.dto.UserProfileDto;
import com.kimaya.flyweb.usermgmt.entities.UserProfileEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserProfileMapper {

    UserProfileDto toDto(UserProfileEntity entity);

    UserProfileEntity toEntity(UserProfileDto dto);

}