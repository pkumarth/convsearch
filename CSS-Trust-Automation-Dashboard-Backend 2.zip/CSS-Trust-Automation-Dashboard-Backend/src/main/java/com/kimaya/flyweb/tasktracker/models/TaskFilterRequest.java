package com.kimaya.flyweb.tasktracker.models;

import lombok.Data;

@Data
public class TaskFilterRequest {

    private String taskName;
    private String taskType;
    private String taskStatus;
    private Integer page;
    private Integer size;
    private String sortBy;
    private Long taskId;
}
