package com.kimaya.flyweb.app.security.constants;

public final class SecurityConstants {
    public static final String JWT_SECRET_KEY = "JWT_SECRET";
    public static final String JWT_HEADER = "Authorization";
}
