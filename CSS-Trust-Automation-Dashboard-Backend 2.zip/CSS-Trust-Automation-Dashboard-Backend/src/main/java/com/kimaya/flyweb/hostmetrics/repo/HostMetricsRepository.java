package com.kimaya.flyweb.hostmetrics.repo;


import com.kimaya.flyweb.hostmetrics.entity.HostMetricsSnapshotEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface HostMetricsRepository extends JpaRepository<HostMetricsSnapshotEntity, Long> {

    // Find snapshots between dates
    List<HostMetricsSnapshotEntity> findByTimestampBetween(LocalDateTime start, LocalDateTime end);

    // Find latest snapshot
    @Query("SELECT h FROM HostMetricsSnapshotEntity h WHERE h.timestamp = " +
            "(SELECT MAX(h2.timestamp) FROM HostMetricsSnapshotEntity h2)")
    HostMetricsSnapshotEntity findLatestSnapshot();

    // Find daily snapshots
    @Query("SELECT h FROM HostMetricsSnapshotEntity h WHERE DATE(h.timestamp) = DATE(:date)")
    List<HostMetricsSnapshotEntity> findDailySnapshots(@Param("date") LocalDateTime date);

    // Find weekly snapshots
    @Query("SELECT h FROM HostMetricsSnapshotEntity h WHERE " +
            "EXTRACT(YEAR FROM h.timestamp) = EXTRACT(YEAR FROM :date) AND " +
            "EXTRACT(WEEK FROM h.timestamp) = EXTRACT(WEEK FROM :date)")
    List<HostMetricsSnapshotEntity> findWeeklySnapshots(@Param("date") LocalDateTime date);

    // Find monthly snapshots
    @Query("SELECT h FROM HostMetricsSnapshotEntity h WHERE " +
            "EXTRACT(YEAR FROM h.timestamp) = EXTRACT(YEAR FROM :date) AND " +
            "EXTRACT(MONTH FROM h.timestamp) = EXTRACT(MONTH FROM :date)")
    List<HostMetricsSnapshotEntity> findMonthlySnapshots(@Param("date") LocalDateTime date);
}