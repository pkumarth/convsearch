package com.kimaya.flyweb.common;

public final class ApplicationConstants {

}
