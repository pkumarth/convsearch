package com.kimaya.flyweb.app;

import jakarta.annotation.PostConstruct;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Properties;

@Service
public class VersionService {

    private String appVersion;

    @PostConstruct
    public void printVersion() {
        System.out.println("\n\n\n\n\n\n Application Version: " + appVersion);
        System.out.println("\n\n\n\n\n\n\n");

    }

    public String getAppVersion() {
        return appVersion;
    }

    public VersionService() {
        try {
            Resource resource = new ClassPathResource("version.properties");
            Properties props = PropertiesLoaderUtils.loadProperties(resource);
            System.out.println("Application Version: " + props.getProperty("application.version"));
            appVersion = props.getProperty("application.version");
        } catch (IOException e) {
            System.err.println("Failed to load version.properties: " + e.getMessage());
        }
    }

}
