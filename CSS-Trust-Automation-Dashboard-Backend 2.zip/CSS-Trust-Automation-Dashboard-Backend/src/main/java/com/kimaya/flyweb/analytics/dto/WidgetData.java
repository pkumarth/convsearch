package com.kimaya.flyweb.analytics.dto;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class WidgetData {
    private String widgetId;
    private List<Map<String, Object>> widgetData;
}
