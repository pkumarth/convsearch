package com.kimaya.flyweb.usermgmt.mapper;

import com.kimaya.flyweb.usermgmt.dto.UserDto;
import com.kimaya.flyweb.usermgmt.entities.UserEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")

public interface UserMapper {
/*
    @Mapping(source = "userProfile", target = "userProfile")
    @Mapping(source = "roleEntities", target = "roleEntities")*/
    UserDto toDTO(UserEntity userEntity);

    UserEntity toEntity(UserDto userDto);
}
