package com.kimaya.flyweb.tasktracker.repo;

import com.kimaya.flyweb.tasktracker.entities.TaskEntity;
import com.kimaya.flyweb.tasktracker.entities.TaskLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TaskLogRepository extends JpaRepository<TaskLogEntity, Long> {

    List<TaskLogEntity> findByTask(TaskEntity task);


    TaskLogEntity save(TaskLogEntity taskLogEntity);


    @Modifying
    @Transactional
    @Query(value = "INSERT INTO Task_Logs (Task_Id, log_date_time, log_message, progress_percentage) " +
            "VALUES (:taskId, :logDateTime, :logMessage, :progressPercentage)", nativeQuery = true)
    void saveTaskLog(
            @Param("taskId") Long taskId,
            @Param("logDateTime") LocalDateTime logDateTime,
            @Param("logMessage") String logMessage,
            @Param("progressPercentage") Integer progressPercentage
    );

    List<TaskLogEntity> findByTask_TaskIdOrderByLogDateTimeDesc(Long taskId);
}
