package com.kimaya.flyweb.tasktracker.controller;


import com.kimaya.flyweb.tasktracker.dto.AgentDto;
import com.kimaya.flyweb.tasktracker.dto.TaskDto;
import com.kimaya.flyweb.tasktracker.dto.TaskLogDto;
import com.kimaya.flyweb.tasktracker.models.TaskCreateRequest;
import com.kimaya.flyweb.tasktracker.models.TaskFilterRequest;
import com.kimaya.flyweb.tasktracker.usecases.AgentUseCase;
import com.kimaya.flyweb.tasktracker.usecases.TaskCoreUseCase;
import com.kimaya.flyweb.usermgmt.controller.models.FlyWebCommonRestResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/taskctrl")
@PreAuthorize("hasRole('ADMIN')")
public class TaskPortalController {
    @Autowired
    AgentUseCase agentUseCase;

    @Autowired
    CommonRestUtils commonRestUtils;

    @Autowired
    TaskCoreUseCase taskCoreUseCase;

    @PostMapping("/create")
    public ResponseEntity<FlyWebCommonRestResponse> createTask(@RequestBody TaskCreateRequest request, @RequestHeader HttpHeaders headers) {
        AgentDto agentDto = agentUseCase.findAgentById(request.getAgentId());
        boolean failed = false;

        if (agentDto == null) {
            failed = true;
        } else {
            try {
                taskCoreUseCase.createTask(agentDto.getId(), request);
                FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
                return new ResponseEntity<>(response, HttpStatus.OK);
            }catch (Exception e) {
                failed = true;
            }
        }
        FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(false, 500, "Invalid Credentials", "Invalid Credentials");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @PostMapping("/getAll")
    public ResponseEntity<FlyWebCommonRestResponse> getAllTasks(
            @RequestBody TaskFilterRequest filter
    ) {
        if(filter == null) {
            filter = new TaskFilterRequest();
        }
        if(filter.getPage() == null) {
            filter.setPage(0);
        }

        if(filter.getSize() == null) {
            filter.setSize(-1);
        }
        List<TaskDto> tasks = taskCoreUseCase.getAllTasks(filter, filter.getPage(), filter.getSize(), filter.getSortBy());
        FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
        response.setResult(CommonRestUtils.listToMap(Collections.singletonList(tasks),"content"));
        return ResponseEntity.ok(response);
    }
    @GetMapping("/getById")
    public ResponseEntity<FlyWebCommonRestResponse> getById(@RequestParam(name = "id") Long taskId) {
        TaskFilterRequest filter = new TaskFilterRequest();
        filter.setPage(0);
        filter.setSize(100);
        filter.setTaskId(taskId);

        TaskDto taskDto = taskCoreUseCase.getAllTasks(filter, 0,100,"taskId").get(0);
        FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");

        List<TaskLogDto> taskLogDtoList = taskCoreUseCase.getAllTasksLogs(taskId);
        Map<String,Object> map = new HashMap<>();
        map.put("logs",taskLogDtoList);
        map.put("task",taskDto);

        response.setResult( map);
        return ResponseEntity.ok(response);
    }


    @PostMapping("/getAllTaskLogs")
    public ResponseEntity<FlyWebCommonRestResponse> getAllTasksLog(
            @RequestBody TaskFilterRequest filter
    ) {
        if(filter == null) {
            filter = new TaskFilterRequest();
        }
        if(filter.getPage() == null) {
            filter.setPage(0);
        }

        if(filter.getSize() == null) {
            filter.setSize(-1);
        }
        List<TaskLogDto> tasks = taskCoreUseCase.getAllTasksLogs(filter.getTaskId());// .getAllTasks(filter, filter.getPage(), filter.getSize(), filter.getSortBy());
        FlyWebCommonRestResponse response = commonRestUtils.getResponseTemplate(true, 200, "Successfully Done!", "Successfully Done!");
        response.setResult(CommonRestUtils.listToMap(Collections.singletonList(tasks),"content"));
        return ResponseEntity.ok(response);
    }
}
