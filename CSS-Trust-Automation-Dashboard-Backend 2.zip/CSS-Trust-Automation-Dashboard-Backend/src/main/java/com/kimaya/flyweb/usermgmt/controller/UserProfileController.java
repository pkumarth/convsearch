package com.kimaya.flyweb.usermgmt.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kimaya.flyweb.usermgmt.controller.models.FlyWebCommonRestResponse;
import com.kimaya.flyweb.usermgmt.dto.UserDto;
import com.kimaya.flyweb.usermgmt.usecases.UserDataService;
import com.kimaya.flyweb.usermgmt.usecases.UserProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;


@RestController
@RequestMapping("/profile")
@PreAuthorize("isAuthenticated()")
public class UserProfileController {
    @Autowired
    private UserProfileService profileService;

    @Autowired
    private UserDataService userDataService;

    @GetMapping
    public ResponseEntity<FlyWebCommonRestResponse> getCurrentUserProfile() {
        Authentication authentication  = SecurityContextHolder.getContext().getAuthentication();
        String userName = authentication.getName();
        UserDto userDto = userDataService.findByUsername(userName);

        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> map = objectMapper
                .convertValue(userDto.getUserProfile(), new TypeReference<Map<String, Object>>() {});

        FlyWebCommonRestResponse response = new FlyWebCommonRestResponse();
        response.setSuccess(true);
        response.setMessage("Successfully retrieved user profile");
        response.setCause("Successfully retrieved user profile");
        response.setCode(200);
        response.setResult(map);
        return ResponseEntity.ok(response);
        //return ResponseEntity.ok(profileService.getCurrentUserProfile());

    }
/*
    @PutMapping
    public ResponseEntity<UserProfileDto> updateProfile(@Valid @RequestBody UpdateProfileRequest request) {
        return ResponseEntity.ok(profileService.updateProfile(request));
    }*/
/*
    @DeleteMapping
    public ResponseEntity<?> deleteProfile() {
        profileService.deleteCurrentUserProfile();
        return ResponseEntity.ok(new ApiResponse(true, "Profile deleted successfully"));
    }

    @PostMapping("/picture")
    public ResponseEntity<?> updateProfilePicture(@RequestParam("file") MultipartFile file) {
        String pictureUrl = profileService.updateProfilePicture(file);
        return ResponseEntity.ok(new ApiResponse(true, pictureUrl));
    }*/
}