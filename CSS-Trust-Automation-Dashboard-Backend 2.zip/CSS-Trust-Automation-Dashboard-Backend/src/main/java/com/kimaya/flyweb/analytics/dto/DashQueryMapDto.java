package com.kimaya.flyweb.analytics.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class DashQueryMapDto {

    private Long id;

    private String objectId;

    private String sqlQuery;

    private String dashboardName;

}
