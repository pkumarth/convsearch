package com.kimaya.flyweb.hostmetrics.mapper;

import com.kimaya.flyweb.hostmetrics.dto.HostMetricsSnapshotDto;
import com.kimaya.flyweb.hostmetrics.entity.HostMetricsSnapshotEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.data.domain.Page;

import java.util.List;


@Mapper(componentModel = "spring")
public interface HostMetricsMapper {

    HostMetricsMapper INSTANCE = Mappers.getMapper(HostMetricsMapper.class);

    HostMetricsSnapshotEntity toEntity(HostMetricsSnapshotDto hostMetricsSnapshotDtoDto);

    HostMetricsSnapshotDto toDto(HostMetricsSnapshotEntity taskEntity);

    List<HostMetricsSnapshotDto> toDtoList(List<HostMetricsSnapshotEntity> entities);

    List<HostMetricsSnapshotDto> toDtoPage(Page<HostMetricsSnapshotEntity> entityPage);
}