package com.kimaya.flyweb.tasktracker.repo;

import com.kimaya.flyweb.tasktracker.entities.ActivityLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ActivityLogRepository extends JpaRepository<ActivityLogEntity, Long> {

    List<ActivityLogEntity> findByActorType(String actorType);

    List<ActivityLogEntity> findByAction(String action);
}
