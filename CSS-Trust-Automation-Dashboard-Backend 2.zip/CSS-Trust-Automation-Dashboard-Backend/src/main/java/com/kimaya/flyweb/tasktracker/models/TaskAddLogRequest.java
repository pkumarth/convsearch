package com.kimaya.flyweb.tasktracker.models;

import lombok.Data;

@Data
public class TaskAddLogRequest {
    private String taskId;
    private String message;
    private Integer progressPercent;

}
