package com.kimaya.flyweb.analytics.usecases;

import com.kimaya.flyweb.analytics.dto.DashQueryMapDto;
import com.kimaya.flyweb.analytics.entity.DashQueryMapEntity;
import com.kimaya.flyweb.analytics.mapper.DashQueryMapper;
import com.kimaya.flyweb.analytics.repo.DashQueryMapRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class DashQueryService {
    @Autowired
    private DashQueryMapRepo dashQueryMapRepo;

    @Autowired
    private DashQueryMapper dashQueryMapper;

    public Map<String, String> getAllValues(String dashboardName){
         List<DashQueryMapEntity> list =  dashQueryMapRepo.findAllByDashboardNameIgnoreCase(dashboardName);
        Map<String, String> map = new HashMap<>();
        for (DashQueryMapEntity dashQueryMapEntity : list) {
            map.put(dashQueryMapEntity.getObjectId(),dashQueryMapEntity.getSqlQuery());
        }
         return map;
    }

    public DashQueryMapDto findByObjectIdAndDashboardName(String objectId, String dashboardName){
        DashQueryMapDto dashQueryMapDto;

        /*Object a = dashQueryMapRepo.findRawQuery(objectId,dashboardName);
        a= dashQueryMapRepo.findAll();
        a = dashQueryMapRepo.getDatabaseName();
        */
        DashQueryMapEntity dashQueryMapEntity = dashQueryMapRepo.findByObjectIdAndDashboardName(objectId,dashboardName).orElse(null);
        if(dashQueryMapEntity == null) {
            return null;
        }
        dashQueryMapDto = dashQueryMapper.toDto(dashQueryMapEntity);
        return dashQueryMapDto;
     //   return null;
    }
}
