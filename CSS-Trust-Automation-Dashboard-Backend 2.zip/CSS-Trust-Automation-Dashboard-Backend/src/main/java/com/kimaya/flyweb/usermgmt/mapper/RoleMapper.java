package com.kimaya.flyweb.usermgmt.mapper;

import com.kimaya.flyweb.usermgmt.dto.RoleDto;
import com.kimaya.flyweb.usermgmt.entities.RoleEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface RoleMapper {

    @Mapping(source = "name", target = "name")
    @Mapping(source = "description", target = "description")
    @Mapping(source = "permissions", target = "permissions")
    RoleDto toDto(RoleEntity roleEntity);

    @Mapping(source = "name", target = "name")
    @Mapping(source = "description", target = "description")
    @Mapping(source = "permissions", target = "permissions")
    RoleEntity toEntity(RoleDto dto);
}

