package com.kimaya.flyweb.analytics.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import javax.sql.DataSource;

@Configuration
public class AnalyticsDataSourceConfig {

    @Bean(name = "analyticsDataSource")
    @ConfigurationProperties(prefix = "analytics.datasource")
    public DataSource analyticsDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "analyticsJdbcTemplate")
    public JdbcTemplate analyticsJdbcTemplate(@Qualifier("analyticsDataSource") DataSource secondaryDataSource) {
        return new JdbcTemplate(secondaryDataSource);
    }

    @Bean(name = "analyticsNamedParameterJdbcTemplate")
    public NamedParameterJdbcTemplate analyticsNamedParameterJdbcTemplate(JdbcTemplate analyticsJdbcTemplate) {
        return new NamedParameterJdbcTemplate(analyticsJdbcTemplate);
    }


}
