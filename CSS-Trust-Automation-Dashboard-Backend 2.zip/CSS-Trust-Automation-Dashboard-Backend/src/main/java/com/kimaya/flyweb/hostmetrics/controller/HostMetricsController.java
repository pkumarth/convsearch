package com.kimaya.flyweb.hostmetrics.controller;

import com.kimaya.flyweb.hostmetrics.dto.HostMetricsSnapshotDto;
import com.kimaya.flyweb.hostmetrics.usecase.HostMetricsUseCase;
import com.kimaya.flyweb.tasktracker.controller.CommonRestUtils;
import com.kimaya.flyweb.usermgmt.controller.models.FlyWebCommonRestResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@RestController

@RequestMapping("/host-metrics")
public class HostMetricsController {
    @Autowired
    private HostMetricsUseCase hostMetricsUseCase;

    // Get latest snapshot
    @GetMapping("/snapshots/latest")
    public ResponseEntity<FlyWebCommonRestResponse> getLatestSnapshot() {
        HostMetricsSnapshotDto dto =  hostMetricsUseCase.getLatestSnapshot().get() ;

        FlyWebCommonRestResponse response = CommonRestUtils.getSuccessResponseTemplate();
        response.setResult(CommonRestUtils.pojoToMap(dto));
        return ResponseEntity.ok(response);
    }

    // Get daily snapshots
    @GetMapping("/snapshots/daily")
    public ResponseEntity< FlyWebCommonRestResponse> getDailySnapshots(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        List<HostMetricsSnapshotDto> snapshots = hostMetricsUseCase.getDailySnapshots(date);

        FlyWebCommonRestResponse response = CommonRestUtils.getSuccessResponseTemplate();
        response.setResult(CommonRestUtils.listToMap(Collections.singletonList(snapshots),"snapshots"));

        return ResponseEntity.ok(response);
    }

    // Get weekly snapshots
    @GetMapping("/snapshots/weekly")
    public ResponseEntity<FlyWebCommonRestResponse> getWeeklySnapshots(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        List<HostMetricsSnapshotDto> snapshots = hostMetricsUseCase.getWeeklySnapshots(date);
        FlyWebCommonRestResponse response = CommonRestUtils.getSuccessResponseTemplate();
        response.setResult(CommonRestUtils.listToMap(Collections.singletonList(snapshots),"snapshots"));

        return ResponseEntity.ok(response);
    }

}
