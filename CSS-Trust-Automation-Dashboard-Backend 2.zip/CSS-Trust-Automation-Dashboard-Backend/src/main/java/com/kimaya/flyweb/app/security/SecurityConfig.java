package com.kimaya.flyweb.app.security;

import com.kimaya.flyweb.app.security.filters.*;
import com.kimaya.flyweb.usermgmt.usecases.UserDataService;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@Lazy
@EnableWebSecurity
//@EnableMethodSecurity(securedEnabled = true, jsr250Enabled = true)
@RequiredArgsConstructor
public class SecurityConfig {
    @Autowired
    private Environment environment;

    @Value("${app.security.jwtSecurityKey}")
    private  String jwtSecurityKey;

    @Value("${app.security.openEndPoints}")
    private  String openEndPoints;

    @Value("${app.security.issuer}")
    private  String issuer;

    private Set<String> openEndPointsSet;

    private Set<String> createSet() {
        return Optional.ofNullable(openEndPoints)
                .map(endpoints -> Arrays.stream(endpoints.split(","))
                        .map(String::trim)
                        .collect(Collectors.toUnmodifiableSet()))
                .orElse(Collections.emptySet());
    }



   /*
    private final JwtAuthenticationFilter jwtAuthenticationFilter;
   private final OAuth2AuthenticationSuccessHandler oAuth2AuthenticationSuccessHandler;
    private final OAuth2AuthenticationFailureHandler oAuth2AuthenticationFailureHandler;
    private final CustomOAuth2UserService customOAuth2UserService;

    private final SAMLAuthenticationProvider samlAuthenticationProvider;
    */

    @PostConstruct
    public void init() {
        this.jwtSecurityKey = environment.getRequiredProperty("app.security.jwtSecurityKey");
        this.openEndPoints = environment.getRequiredProperty("app.security.openEndPoints");
        this.issuer = environment.getRequiredProperty("app.security.issuer");
        this.openEndPointsSet = createSet();

        String[] endpoints = openEndPoints.split(",");

    }


    @Configuration
    public class CorsConfig {

        @Bean
        public CorsConfigurationSource corsConfigurationSource() {
            ArrayList<String> allowedOrigins = new ArrayList<>();
            allowedOrigins.add("localhost");
            allowedOrigins.add("http://localhost:4200");

            CorsConfiguration config = new CorsConfiguration();
//            config.setAllowedOrigins( allowedOrigins);
            config.addAllowedOriginPattern("*");
            config.setAllowCredentials(true);
            config.setAllowedHeaders(Collections.singletonList("*"));
            config.setMaxAge(3600L);
            config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
            config.setExposedHeaders(List.of("Authorization", "Content-Type"));

            UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
            source.registerCorsConfiguration("/**", config);

//                return config;
            return source;
        }
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        this.jwtSecurityKey = environment.getRequiredProperty("app.security.jwtSecurityKey");
        this.openEndPoints = environment.getRequiredProperty("app.security.openEndPoints");
        this.issuer = environment.getRequiredProperty("app.security.issuer");
        this.openEndPointsSet = createSet();

        String[] endpoints = openEndPoints.split(",");

        http.csrf(AbstractHttpConfigurer::disable);
        http.cors(Customizer.withDefaults());


        http.authorizeHttpRequests((requests) -> requests
                .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                .requestMatchers("/api/auth/login").permitAll()
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers("/api/oauth2/**").permitAll()
                .requestMatchers("/api/analytics/**").permitAll()
                .requestMatchers("/auth/login").permitAll()
                .requestMatchers("/auth/**").permitAll()
                .requestMatchers("/oauth2/**").permitAll()
                .requestMatchers("/analytics/**").permitAll()
                .requestMatchers("/", "/index.html", "/*.js", "/*.css", "/*.ico", "/assets/**").permitAll()
                .requestMatchers(Arrays.stream(endpoints)
                        .map(String::trim)
                        .toArray(String[]::new)).permitAll()
                .anyRequest().authenticated());

        http.sessionManagement(sessionConfig ->
                    sessionConfig.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

        /*
        http.oauth2Login(oauth2 -> {
                    oauth2.successHandler(null);
                });
        */
        /*
        http.addFilterBefore(authenticationJwtTokenFilter(),
                UsernamePasswordAuthenticationFilter.class)
        */

        http
                .addFilterBefore(new RequestValidationBeforeFilter(), BasicAuthenticationFilter.class)
                .addFilterBefore(new JWTTokenValidatorFilter(jwtSecurityKey,openEndPointsSet), BasicAuthenticationFilter.class)
                .addFilterAt(new AuthoritiesLoggingAtFilter(), BasicAuthenticationFilter.class)
//                .addFilterAfter(new CsrfCookieFilter(), BasicAuthenticationFilter.class)
                .addFilterAfter(new AuthoritiesLoggingAfterFilter(), BasicAuthenticationFilter.class)
                .addFilterAfter(new JWTTokenGeneratorFilter(jwtSecurityKey,openEndPointsSet,issuer), BasicAuthenticationFilter.class);


        /*http.addFilterBefore(authenticationJwtTokenFilter(),
                UsernamePasswordAuthenticationFilter.class);*/

                /*.authorizeHttpRequests((requests) -> requests
                        .requestMatchers("/api/auth/*").permitAll()
                        .requestMatchers("/notices", "/contact", "/error", "/register", "/invalidSession", "/apiLogin").authenticated()) ;*/
//                .addFilterAfter(new CsrfCookieFilter(), BasicAuthenticationFilter.class)
               /* .addFilterBefore(new RequestValidationBeforeFilter(), BasicAuthenticationFilter.class)
                .addFilterAfter(new AuthoritiesLoggingAfterFilter(), BasicAuthenticationFilter.class)
                .addFilterAt(new AuthoritiesLoggingAtFilter(), BasicAuthenticationFilter.class)
                .addFilterAfter(new JWTTokenGeneratorFilter(), BasicAuthenticationFilter.class)
                .addFilterBefore(new JWTTokenValidatorFilter(), BasicAuthenticationFilter.class)
                .exceptionHandling(exception -> exception
                        .authenticationEntryPoint((request, response, authException) -> {
                            response.setContentType("application/json");
                            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                            response.getWriter().write("{\"error\": \"Unauthorized\", \"message\": \""
                                    + authException.getMessage() + "\"}");
                        })
                        .accessDeniedHandler((request, response, accessDeniedException) -> {
                            response.setContentType("application/json");
                            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                            response.getWriter().write("{\"error\": \"Forbidden\", \"message\": \""
                                    + accessDeniedException.getMessage() + "\"}");
                        }));
*/

        /*
                // Adding multiple authentication filters in order
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class) ;*/


        http.exceptionHandling(exception -> exception
                .authenticationEntryPoint((request, response, authException) -> {
                    response.setContentType("application/json");
                    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                    response.getWriter().write("{\"error\": \"Unauthorized\", \"message\": \""
                            + authException.getMessage() + "\"}");
                })
                .accessDeniedHandler((request, response, accessDeniedException) -> {
                    response.setContentType("application/json");
                    response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                    response.getWriter().write("{\"error\": \"Forbidden\", \"message\": \""
                            + accessDeniedException.getMessage() + "\"}");
                }));
        http.formLogin(withDefaults());
        http.httpBasic(withDefaults());
        return http.build();
    }


    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationProvider customPwdAuthenticationProvider(
            @Lazy UserDetailsService userDetailsService,
            PasswordEncoder passwordEncoder
    ) {
        return new CustomPwdAuthenticationProvider(userDetailsService, passwordEncoder);
    }

    @Bean
    public UserDataService userDataService() {
        return new UserDataService();
    }

/*
    @Bean
    public AuthenticationManager authenticationManager(@Lazy UserDetailsService userDetailsService,
                                                       PasswordEncoder passwordEncoder) {
        CustomPwdAuthenticationProvider authenticationProvider =
                new CustomPwdAuthenticationProvider(userDetailsService, passwordEncoder);
        ProviderManager providerManager = new ProviderManager(authenticationProvider);
        providerManager.setEraseCredentialsAfterAuthentication(false);
        return  providerManager;
    }*/


}