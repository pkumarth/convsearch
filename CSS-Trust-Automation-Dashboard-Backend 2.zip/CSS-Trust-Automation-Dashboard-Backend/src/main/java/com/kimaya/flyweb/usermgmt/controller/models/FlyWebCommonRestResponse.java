package com.kimaya.flyweb.usermgmt.controller.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Map;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class FlyWebCommonRestResponse {
    private boolean success;
    private Integer code;
    private String message;
    private String cause;
    private Map<String,Object> result;
}
