package com.kimaya.flyweb.tasktracker.usecases;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kimaya.flyweb.tasktracker.common.TaskStatus;
import com.kimaya.flyweb.tasktracker.dto.AgentDto;
import com.kimaya.flyweb.tasktracker.dto.TaskDto;
import com.kimaya.flyweb.tasktracker.dto.TaskLogDto;
import com.kimaya.flyweb.tasktracker.entities.AgentEntity;
import com.kimaya.flyweb.tasktracker.entities.TaskEntity;
import com.kimaya.flyweb.tasktracker.entities.TaskLogEntity;
import com.kimaya.flyweb.tasktracker.mapper.TaskLogMapper;
import com.kimaya.flyweb.tasktracker.mapper.TaskMapper;
import com.kimaya.flyweb.tasktracker.models.TaskCreateRequest;
import com.kimaya.flyweb.tasktracker.models.TaskFilterRequest;
import com.kimaya.flyweb.tasktracker.models.TaskStatusUpdateRequest;
import com.kimaya.flyweb.tasktracker.repo.AgentRepository;
import com.kimaya.flyweb.tasktracker.repo.TaskLogRepository;
import com.kimaya.flyweb.tasktracker.repo.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Service
@Transactional
@Lazy
public class TaskCoreUseCase {
    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private TaskLogRepository taskLogRepository;

    @Autowired
    private TaskMapper taskMapper;
    @Autowired
    private AgentRepository agentRepository;
    @Autowired
    private TaskLogMapper taskLogMapper;

    public List<TaskDto> getTasks(AgentDto agentDto) {
        Long id = agentDto.getId();
        String status = TaskStatus.QUEUED.name();
        List<TaskEntity> entityList = taskRepository.findByAgent_IdAndTaskStatus(id, status);
        List<TaskDto> taskDtoList = new ArrayList<>();
        for (TaskEntity taskEntity : entityList) {
            TaskDto taskDto = taskMapper.toTaskDto(taskEntity);
            taskDtoList.add(taskDto);
        }
        return taskDtoList;
    }

    /*public void updateTaskStatus(Long agentId, List<Long> taskIds, TaskStatus status) {

        for (Long taskId : taskIds) {
            taskRepository.markTaskCompleted(agentId, taskId,status.toString(),"","");
        }
    }*/

    public void processStatusUpdate(TaskStatusUpdateRequest request, Long agentId) {
        Long taskId = Long.parseLong(request.getTaskId());

        TaskEntity taskEntity = taskRepository.findByAgent_IdAndTaskId(agentId, taskId);
        if (taskEntity == null) {
            return;
        }

        TaskStatus newStatus = TaskStatus.valueOf(request.getStatus());
        TaskStatus curStatus = TaskStatus.valueOf(taskEntity.getTaskStatus());

        if ((curStatus == TaskStatus.QUEUED) && (newStatus == TaskStatus.IN_PROGRESS)) {
            taskStarted(agentId, taskId, newStatus);
        }

        taskLogRepository.saveTaskLog(taskId, LocalDateTime.now(), request.getLogMessage(), request.getProgressPercentage());
    }

    public void taskCompleted(Long agentId, Long taskId, TaskStatus status, String message, String result) {
        TaskEntity taskEntity = taskRepository.findByAgent_IdAndTaskId(agentId, taskId);
        if (taskEntity == null) {
            return;
        }
        if (taskEntity.getTaskStatus().equalsIgnoreCase(TaskStatus.QUEUED.name())) {
            taskRepository.markTaskStarted(agentId, taskId, status.name(), LocalDateTime.now());
            taskRepository.markTaskCompleted(agentId, taskId, status.name(), message, result, LocalDateTime.now());
        } else {
            taskRepository.markTaskCompleted(agentId, taskId, status.name(), message, result, LocalDateTime.now() );
        }
        taskLogRepository.saveTaskLog(taskId, LocalDateTime.now(), message, 100);
    }

    public void taskStarted(Long agentId, Long taskId, TaskStatus status) {
        TaskEntity taskEntity = taskRepository.findByAgent_IdAndTaskId(agentId, taskId);
        if (taskEntity == null) {
            return;
        }
        taskRepository.markTaskStarted(agentId, taskId, status.name(), LocalDateTime.now());
    }

    public void addTaskLog(Long agentId, Long taskId, String message, Integer progressPercent, LocalDateTime timestamp) throws Exception {

        TaskEntity taskEntity = taskRepository.findByAgent_IdAndTaskId(agentId, taskId);
        if (taskEntity == null) {
            throw new Exception("Invalid task input");
        }
        taskLogRepository.saveTaskLog(taskId, LocalDateTime.now(), message, progressPercent);
    }

    public void createTask(Long id, TaskCreateRequest request) throws Exception {
        TaskEntity taskEntity = new TaskEntity();
        AgentEntity agentEntity = agentRepository.findById(request.getAgentId()).orElse(null);
        if (agentEntity == null) {
            throw new Exception("Agent not found!");
        }
        taskEntity.setTaskName(request.getTaskName());
        taskEntity.setTaskType(request.getTaskType());
        taskEntity.setTaskSubType(request.getTaskSubType());
        taskEntity.setTaskTags(" ");//TODO request.getTaskTags()

        String hardCodedText = """
                {
                            "template": "ewogICJwbGF5Ym9vayI6ICIvYW5zaWJsZS9wbGF5Ym9va3MvbWFjX3VwZGF0ZXMueW1sIiwKICAiaW52ZW50b3J5IjogIi9hbnNpYmxlL3BsYXlib29rcy9tYWNfaW52ZW50b3J5LmluaSIsCiAgImV4dHJhX3ZhcnMiOiAidGFyZ2V0X2hvc3RzPWFsbCIgLAogICJwb3N0cnVuX3NjcmlwdCIgOiAicG9zdHByb2Nlc3NfZGVmYXVsdC5weSIsCiAgInBvc3RydW5fc2NyaXB0X2FyZ3MiIDogWwoJICB7CgkJICAibm9uZSI6Im5vbmUiCgkgIH0KICBdLAogICJkZWJ1ZyIgOiB0cnVlCn0K",
                            "inventory": "W21hY29zX2hvc3RzXQptYWNvc19ob3N0IGFuc2libGVfaG9zdD0xMC4xMDguOTMuMjA5IGFuc2libGVfY29ubmVjdGlvbj1zc2ggYW5zaWJsZV91c2VyPWVjMi11c2VyIGFuc2libGVfYmVjb21lPXllcyBhbnNpYmxlX3NzaF9wcml2YXRlX2tleV9maWxlPS4va2V5cy9tYWNvcy5wZW0KClthbGw6dmFyc10KYW5zaWJsZV9zc2hfY29tbW9uX2FyZ3M9Jy1vIFN0cmljdEhvc3RLZXlDaGVja2luZz1ubycK",
                            "trigger": "mac_update",
                            "taskid": 1,
                            "eargs": null
                          }
                """;

        taskEntity.setAgent(agentEntity);
        taskEntity.setTaskStatus(TaskStatus.QUEUED.name());
        taskEntity.setTaskInput(extractAndEncode(request.getTaskInput()));

//        taskEntity.setTaskInput(hardCodedText);
        taskEntity.setTaskLogs("");
        taskEntity.setProgress(0);
        TaskEntity saved = taskRepository.save(taskEntity);
        return;

    }

    public static String extractAndEncode(String inputJson) throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        // Step 1: Parse the original JSON
        JsonNode root = mapper.readTree(inputJson);

        // Step 2: Convert JsonNode to compact JSON string
        String compactJson = mapper.writeValueAsString(root);

        // Step 3: Base64 encode it
        return Base64.getEncoder().encodeToString(compactJson.getBytes());
    }
    private String getTriggerFromSubType(String subType) {
        //MAC_PATCH, LINUX_PATCH, WIN_PATCH, LINUX_EDR_INSTALL, WIN_EDR_INSTALL
        String trigger = null;
        switch (subType) {
            case "LINUX_EDR_INSTALL":
                trigger= "install_linux_edr";
                break;
            case "WIN_EDR_INSTALL":
                trigger="install_win_edr";
            break;
            default:
                trigger = subType.toLowerCase();
        }
        return trigger;
    }

    public List<TaskDto> getAllTasks(TaskFilterRequest filter, int page, int size, String sortBy) {
        Sort sort = Sort.by(sortBy != null ? sortBy : "taskId");


        List<TaskDto> list = new ArrayList<>();
        if (page < 0 || size < 0) {
            List<TaskEntity> entityList = taskRepository.findAll(
                    TaskRepository.withDynamicQuery(filter),
                    sort
            );
            list = taskMapper.toDtoList(entityList);
        } else {
            Page<TaskEntity> res;
            PageRequest pageRequest = PageRequest.of(page, size, sort);
            res = taskRepository.findAll(
                    TaskRepository.withDynamicQuery(filter),
                    pageRequest
            );
            list = taskMapper.toDtoPage(res);
        }
        return list;
    }

    public List<TaskLogDto> getAllTasksLogs(Long taskId) {
        List<TaskLogEntity> taskLogEntityList = taskLogRepository.findByTask_TaskIdOrderByLogDateTimeDesc(taskId);
        List<TaskLogDto> taskLogDtos = taskLogMapper.toDtoList(taskLogEntityList);

        return taskLogDtos;
    }

}
