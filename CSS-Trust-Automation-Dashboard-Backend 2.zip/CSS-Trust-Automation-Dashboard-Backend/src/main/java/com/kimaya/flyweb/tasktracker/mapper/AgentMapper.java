package com.kimaya.flyweb.tasktracker.mapper;

import com.kimaya.flyweb.tasktracker.dto.AgentDto;
import com.kimaya.flyweb.tasktracker.entities.AgentEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface AgentMapper {

    AgentMapper INSTANCE = Mappers.getMapper(AgentMapper.class);

    AgentEntity toAgentEntity(AgentDto agentDto);

    AgentDto toAgentDto(AgentEntity agentEntity);
}