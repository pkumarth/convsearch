package com.kimaya.flyweb.tasktracker.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@RequiredArgsConstructor
@Data
public class TaskLogDto {

    private Long taskLogId;
    private Long taskId;
    private Date logDateTime;
    private String logMessage;
    private Integer progressPercentage;
}
