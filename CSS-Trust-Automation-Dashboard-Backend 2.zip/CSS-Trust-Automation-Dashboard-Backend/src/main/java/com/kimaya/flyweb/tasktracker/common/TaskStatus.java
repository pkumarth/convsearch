package com.kimaya.flyweb.tasktracker.common;

public enum TaskStatus {
    QUEUED,IN_PROGRESS,COMPLETED,FAILED
}
