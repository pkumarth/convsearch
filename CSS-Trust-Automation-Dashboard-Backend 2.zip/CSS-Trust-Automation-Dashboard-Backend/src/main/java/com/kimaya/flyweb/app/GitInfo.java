package com.kimaya.flyweb.app;

public class GitInfo {

}
