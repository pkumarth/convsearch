package com.kimaya.flyweb.common.controller;

import com.kimaya.flyweb.usermgmt.controller.models.FlyWebCommonRestResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<?> handleResourceNotFoundException(ResourceNotFoundException ex) {
//        ApiResponse apiResponse = new ApiResponse(false, ex.getMessage());
        FlyWebCommonRestResponse restResponse = new FlyWebCommonRestResponse();
        restResponse.setSuccess(false);
        restResponse.setMessage("ResourceNotFoundException");
        restResponse.setCause(ex.getMessage());
        restResponse.setCode(HttpStatus.NOT_FOUND.value());

        return new ResponseEntity<>(restResponse, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<?> handleBadRequestException(BadRequestException ex) {
//        ApiResponse apiResponse = new ApiResponse(false, ex.getMessage());

        FlyWebCommonRestResponse restResponse = new FlyWebCommonRestResponse();
        restResponse.setSuccess(false);
        restResponse.setMessage("BadRequestException");
        restResponse.setCause(ex.getMessage());
        restResponse.setCode(HttpStatus.BAD_REQUEST.value());
        return new ResponseEntity<>(restResponse, HttpStatus.BAD_REQUEST);

//        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex,
            HttpHeaders headers,
            HttpStatusCode status,
            WebRequest request) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });

        FlyWebCommonRestResponse restResponse = new FlyWebCommonRestResponse();
        restResponse.setSuccess(false);
        restResponse.setMessage("BadRequestException");
        restResponse.setCause(errors.toString());
        restResponse.setCode(HttpStatus.BAD_REQUEST.value());
        return new ResponseEntity<>(restResponse, HttpStatus.BAD_REQUEST);

//        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<?> handleAccessDeniedException(AccessDeniedException ex) {
//        ApiResponse apiResponse = new ApiResponse(false, "Access Denied");


        FlyWebCommonRestResponse restResponse = new FlyWebCommonRestResponse();
        restResponse.setSuccess(false);
        restResponse.setMessage("Access Denied");
        restResponse.setCause("Access Denied");
        restResponse.setCode(HttpStatus.FORBIDDEN.value());
        return new ResponseEntity<>(restResponse, HttpStatus.FORBIDDEN);

//        return new ResponseEntity<>(apiResponse, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleGlobalException(Exception ex) {
//        ApiResponse apiResponse = new ApiResponse(false, "An unexpected error occurred");


        FlyWebCommonRestResponse restResponse = new FlyWebCommonRestResponse();
        restResponse.setSuccess(false);
        restResponse.setMessage("Server Error");
        restResponse.setCause(ex.getMessage());
        restResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        return new ResponseEntity<>(restResponse, HttpStatus.OK);

//        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    @ExceptionHandler(BadCredentialsException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ResponseEntity<?> handleBadCredentials(BadCredentialsException ex) {

        /*FlyWebCommonRestResponse restResponse = new FlyWebCommonRestResponse();
        restResponse.setMessage("Authentication failed");
        restResponse.setCause("Bad credentials");
        restResponse.setCode(401);*/

        FlyWebCommonRestResponse restResponse = new FlyWebCommonRestResponse();
        restResponse.setSuccess(false);
        restResponse.setMessage("Authentication failed");
        restResponse.setCause("Bad Credentials");
        restResponse.setCode(HttpStatus.UNAUTHORIZED.value());
        return new ResponseEntity<>(restResponse, HttpStatus.UNAUTHORIZED);

//        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Bad credentials");
    }
}