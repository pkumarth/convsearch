package com.kimaya.flyweb.tasktracker.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@RequiredArgsConstructor
@Data
public class AgentDto {

    private Long id;
    private String agentName;
    private String agentClientId;
    private String agentStatus;
    private LocalDateTime agentLastReportedTime;
}
