package com.kimaya.flyweb.tasktracker.models;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.List;

@Data
public class TaskCreateRequest {

    @NotBlank(message = "Task Name is required")
    @Size(min = 3, max = 255, message = "Task Name must be between 3 and 255 characters")
    private String taskName;

    @NotNull(message = "Task Type is required")
    private String taskType;

    private String taskSubType;

    private List<String> taskTags;

    @NotNull(message = "Task Input is required")
    private String taskInput;

    @NotNull(message = "Agent Id is required")
    private Long agentId;

}
