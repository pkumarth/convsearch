package com.kimaya.flyweb.tasktracker.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@RequiredArgsConstructor
@Data
@Entity
@Table(name = "Task_Master")
public class TaskEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JoinColumn(name = "task_id")
    private Long taskId;

    @Column(nullable = false, name="task_name")
    private String taskName;

    @Column(name = "task_type")
    private String taskType;

    @Column(name = "task_subtype")
    private String taskSubType;
    private Integer progress;
    @ManyToOne
    @JoinColumn(name = "Task_Agent_Id")
    private AgentEntity agent;

    @Column(nullable = false)
    private String taskStatus;

//    @Lob
    @Column(columnDefinition = "TEXT")
    private String taskTags; // Consider using a suitable data structure like a List or Set

//    @Lob
    @Column(columnDefinition = "TEXT")
    private String taskInput;


//    @Lob
    @Column(columnDefinition = "TEXT")
    private String taskLogs; // Consider using a suitable data structure like a List or Set


//    @Lob
    @Column(name = "task_result", columnDefinition = "TEXT")
    private String taskResult;

    @Column(name = "task_start_time")
    private LocalDateTime taskStartTime;

    @Column(name = "task_end_time")
    private LocalDateTime taskEndTime;

}
