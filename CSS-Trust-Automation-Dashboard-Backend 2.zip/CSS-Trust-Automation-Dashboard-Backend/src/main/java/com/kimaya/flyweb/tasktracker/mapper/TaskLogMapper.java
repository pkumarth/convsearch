package com.kimaya.flyweb.tasktracker.mapper;


import com.kimaya.flyweb.tasktracker.dto.TaskLogDto;
import com.kimaya.flyweb.tasktracker.entities.TaskLogEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface TaskLogMapper {

    TaskLogMapper INSTANCE = Mappers.getMapper(TaskLogMapper.class);

    TaskLogEntity toTaskLogEntity(TaskLogDto taskLogDto);

    TaskLogDto toTaskLogDto(TaskLogEntity taskLogEntity);

    List<TaskLogDto> toDtoList(List<TaskLogEntity> entities);
}
